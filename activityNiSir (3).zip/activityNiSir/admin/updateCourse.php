<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if (isset($_POST['update'])) {
    // Get the updated data from the form
    $id = $_POST['id'];
    $N_Course = $_POST['N_Course'];
   
   
    

    // Update the record in the database
    $updateSql = "UPDATE course SET N_Course=?  WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param("si", $N_Course, $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;'>Record Successfully Deleted</h3>";
        
    } else {
        $_SESSION['error'] = "Error updating record: " . $stmt->error;
    }

    // Redirect to the dashboard page
    header("location: courseTable.php");
}
?>