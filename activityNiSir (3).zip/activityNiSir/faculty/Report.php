<?php
session_start();
include("../admin/databse/dbcon.php");
require_once 'phpspreadsheet/vendor/autoload.php'; // Include PhpSpreadsheet autoloader

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Query to get data about the logged-in user from the faculty table
$faculty_query = "SELECT * FROM faculty WHERE id = '$user_id'";
$faculty_result = mysqli_query($con, $faculty_query);

if (!$faculty_result || mysqli_num_rows($faculty_result) == 0) {
    echo "Error: User data not found";
    exit();
}

$user_data = mysqli_fetch_assoc($faculty_result);

// Query to get the total number of students for the logged-in faculty
$student_count_query = "SELECT COUNT(*) as total_students
                       FROM student
                       WHERE facultyfk = '$user_id'";
$student_count_query_run = mysqli_query($con, $student_count_query);

// diplay in the table all of the student registered
$student_query = "SELECT * FROM student WHERE facultyfk = '$user_id'";
$student_result = mysqli_query($con, $student_query);

if (!$student_result) {
    // Handle the error, e.g., display an error message or redirect
    echo "Error: Unable to fetch student data.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/dashboard.css">

    <title>Dashboard</title>
</head>
<style>
    body {
        background-color: #f4f4f4;
        margin: 0;
    }

    dashboard {
        max-width: 800px;
        margin: 20px auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        margin-right: 90px;
        color: #333;
    }

    .info-container {
        margin-top: 20px;
    }

    .info-item {
        display: flex;
        justify-content: space-between;
        margin-bottom: 10px;
        padding: 10px;
        background-color: #f0f0f0;
        border-radius: 5px;
    }

    .label {
        font-weight: bold;
    }

    header {
        width: 100%;
        position: relative;
        height: 88px;
        background-color: white;
        display: flex;
        justify-content: space-between;
        padding: 0 20px;
        align-items: center;
        box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
    }

    .logo {
        font-size: 11px;
        font-weight: 600;
        color: #576cbc;
        margin-left: 20px;
        display: flex;
        align-items: center;
    }

    .logo h1 {
        color: #576cbc;
    }

    .hamburger {
        display: flex;
    }

    .nav-bar ul {
        display: flex;
        list-style: none;
        margin: 5px;
        padding: 5px;
    }

    .nav-bar ul li {
        display: flex;
        margin-right: 95px;
    }

    .nav-bar ul a {
        text-decoration: none;
        display: flex;
        position: absolute;
        margin-top: -10px;
        color: #576cbc;
        font-size: 18px;
        margin-left: 650px;
        transition: .2s;
    }

    .list a {
        color: #fff;
        background: #5500cb;
        height: 45px;
        width: 160px;
        font-size: 18px;
        border-radius: 5px;
        cursor: pointer;
    }

    .recent-Articles {
        margin-left: 50vh;
        margin-top: 100px;
    }

    .data-table {
        width: 100%;
        max-width: 100%;
        border-collapse: collapse;
        white-space: nowrap;
        margin-top: 20px;
        background-color: #fff;
        border-radius: 20px;
        box-shadow: 3px 3px 10px rgba(0, 30, 87, 0.751);
    }

    .data-table td.no-wrap {
        white-space: nowrap;
        background-color: #ffffff;
        text-align: center;
    }

    .search-container {
        margin-left: 760px;
    }

    #search-form {
        display: inline-block;
    }

    #search-input {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-right: 5px;
    }

    button[type="submit"] {
        background-color: #5500cb;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 5px;
        cursor: pointer;
    }

    .action-buttons {
        display: flex;
        gap: 5px;
    }
</style>

<body>
    <header>
        <div class="logo">
            <div class="hamburger">
                <h1>Welcome, <?php echo $user_data['f_name'] ?>!</h1>
            </div>

            <nav class="nav-bar">
                <ul>
                    <li><a href="dashboard.php" class="active">Home</a></li>
                    <li><a href="student.php" class="active">Students</a></li>
                    <li><a href="Grade.php" class="active">Grade</a></li>
                    <li><a href="Report.php" class="active">Report</a></li>
                    <li><a href="login.php" class="active">Logout</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="main">
        <div style="margin-left:25vh;" class="report-container">
            <div class="report-header">
                <h1 style="position: relative; margin-top:-30px;" class="recent-Articles">Registered Students</h1>
            </div>

            <div class="search-container">
                <form id="search-form">
                    <input type="text" id="search-input" placeholder="Search for students">
                    <button type="submit">Search</button>
                </form>
            </div>

            <div class="report-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Id Number</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Gender</th>
                            <th>Course</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        while ($row = mysqli_fetch_assoc($student_result)) {
                            echo '<tr>';
                            echo '<td class="no-wrap">' . $row['idnumber'] . '</td>';
                            echo '<td class="no-wrap">' . $row['lname'] . '</td>';
                            echo '<td class="no-wrap">' . $row['fname'] . '</td>';
                            echo '<td class="no-wrap">' . $row['mname'] . '</td>';
                            echo '<td class="no-wrap">' . $row['gender'] . '</td>';
                            echo '<td class="no-wrap">' . $row['course'] . '</td>';

                            echo '<td class="action-buttons">';
                            echo '<a class="edit-button" href="generateExcel.php?student_id=' . $row['id'] . '">DL to Excel</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        ?>
                    </tbody>
                </table>
            </div>

            <div id="not-found-message" style="display: none; margin-left: 400px; font-size: 20px; color: red;">No
                matching results found.</div>
        </div>
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function () {
            const searchForm = document.getElementById("search-form");
            const searchInput = document.getElementById("search-input");
            const dataTable = document.querySelector(".data-table");
            const notFoundMessage = document.getElementById("not-found-message");

            searchForm.addEventListener("submit", function (e) {
                e.preventDefault();
                const searchValue = searchInput.value.toLowerCase();
                const rows = dataTable.querySelectorAll("tbody tr");
                let found = false;

                rows.forEach((row) => {
                    const rowData = row.textContent.toLowerCase();
                    if (rowData.includes(searchValue)) {
                        row.style.display = "";
                        found = true;
                    } else {
                        row.style.display = "none";
                    }
                });

                // Display or hide the "not found" message
                if (found) {
                    notFoundMessage.style.display = "none";
                } else {
                    notFoundMessage.style.display = "block";
                }
            });
        });
    </script>
</body>

</html>
