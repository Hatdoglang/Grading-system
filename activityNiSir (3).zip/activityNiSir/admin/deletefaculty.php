<?php
session_start(); // Start the session

include("databse/dbcon.php");

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Create and execute the SQL DELETE query
    $sql = "DELETE FROM faculty WHERE id = $id"; // Replace 'your_table_name' with the actual table name
    if ($con->query($sql)) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;
                                           color: #fff;
                                           margin-top:20px;
                                           background: #23dd42;
                                           border-radius: 3px;
                                           width: 410px;
                                           height: 40px;
                                           font-weight: bold;
                                           '>Record Successfully Deleted</h3>";
    } else {
        $_SESSION['error'] = "Error deleting the record: " . $con->error;
    }

    $con->close();  // Close the database connection

    header("location: facultyTable.php");  // Redirect to the dashboard or any other page
} else {
    $_SESSION['error'] = "Invalid record ID";
    header("location: facultyTable.php");  // Redirect with an error message
}
?>