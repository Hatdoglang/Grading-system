<?php
include("index.php");
include("databse/dbcon.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Get form input data and use prepared statements to insert data
    
    $institute = $_POST['N_Course'] ?? "";
   

    if (empty($institute)) {
        echo "<script type='text/javascript'> alert('Please fill in all required fields')</script>";
    } else {
        $query = "INSERT INTO courses (N_Course) VALUES (?)";
        $stmt = mysqli_prepare($con, $query);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $institute);

            if (mysqli_stmt_execute($stmt)) {
                echo "<script type='text/javascript'> alert('Registration Successfully'); window.location.href = 'courseTable.php'; </script>";
                exit();
            } else {
                echo "<script type='text/javascript'> alert('Registration Error')</script>";
                echo "MySQL Error: " . mysqli_error($con); 
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "Error in preparing the SQL statement.";
        }

        mysqli_close($con);
    }
}
?>




<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Student Registration Form</title>
    <link rel="stylesheet" href="css/studen.css">

</head>

<body>
    <style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .container {
        position: relative;
        max-width: 900px;
        width: 600px;
        border-radius: 6px;
        padding: 30px;
        margin: 0 15px;
        background-color: #fff;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }

    .container header {
        position: relative;
        font-size: 20px;
        font-weight: 600;
        color: #333;
    }

    .container header::before {
        content: "";
        position: absolute;
        bottom: -2px;
        height: 3px;
        width: 80px;
        border-radius: 8px;
        background-color: #4070f4;
    }


    .container form {
        position: relative;
        margin-top: 16px;
        min-height: 490px;
        background-color: #fff;
        overflow: hidden;

    }

    .container form .form {
        position: absolute;
        background-color: #fff;
        transition: 0.3s ease;
    }

    .container form .form.second {
        opacity: 0;
        pointer-events: none;
        transform: translateX(100%);
    }

    form.secActive .form.second {
        opacity: 1;
        pointer-events: auto;
        transform: translateX(0);
    }

    form.secActive .form.first {
        opacity: 0;
        pointer-events: none;
        transform: translateX(-100%);
    }


    .container form .details {
        margin-top: 30px;
    }

    .container form.guardian {
        margin-top: 30px;
    }

    .container form .title {
        display: flex;
        margin-bottom: 8px;
        font-size: 16px;
        font-weight: 500;
        margin: 6px 0;
        color: #333;
    }

    .container form .fields {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
    }

    .container .fields .input-fields {
        display: flex;
        width: calc(100% / 3- 15px);
        flex-direction: column;
        margin: 4px 0;
    }

    .input-fields input {
        outline: none;
        height: 39px;
        padding: 0 15px;
        font-size: 14px;
        color: #333;
        font-weight: 500;
        width: 270px;
        border: 1px solid #aaa;
        border-radius: 5px;
        margin: 8px 0;

    }

    .input-fields select {
        outline: none;
        height: 39px;
        padding: 0 15px;
        font-size: 14px;
        color: #333;
        font-weight: 500;
        width: 270px;
        border: 1px solid #aaa;
        border-radius: 5px;
        margin: 8px 0;

    }

    .input-fields label {
        font-size: 14px;
        font-weight: 500;
        color: #2e2e2e;
    }

    .input-fields input:is(:focus, :valid) {
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.13);
    }

    .input-fields input[type="date"] {
        color: #707070;
    }

    .input-fields input[type="date"]:valid {
        color: #333;
    }

    .container form button,
    .backBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 100%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container form button,
    .bacckBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 100%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container form button,
    .container form .backBtn {
        font-size: 16px;
        font-weight: 400;
    }

    .container form button,
    .container form .bacckBtn {
        font-size: 16px;
        font-weight: 400;
    }

    form button:hover {
        background-color: #265df2;
    }

    form button i,
    form .backBtn i {
        margin: 0 6px;
    }

    form button i,
    form .bacckBtn i {
        margin: 0 6px;
    }

    form .backBtn i {
        transform: rotate(180deg);
    }

    form .bacckBtn i {
        transform: rotate(180deg);
    }


    form .buttons {
        display: flex;
        align-items: center;
    }

    form .buttons button,
    .backBtn {
        margin-right: 14px;
    }

    form .buttons button,
    .bacckBtn {
        margin-right: 14px;
    }
    </style>

    <div style=" margin-top: 40px;" class="container">
        <header>Registration</header>

        <form action="course.php" method="POST">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Course Detials</span>
                    <div class="fields">



                    <div class="input-fields">
                            <label>Course</label>
                            <input type="text" name="N_Course" placeholder="Enter Course" required>
                        </div>





                    </div>
                </div>
                <div class="buttons">
                    <div class="bacckBtn" onclick="cancelRegistration()">
                        <i class="uil uil-navigator"></i>

                        <span class="btntext">Cancel</span>
                    </div>
                    <button class="nextBtn">
                        <span class="btntext">Submit</span>
                        <i class="uil uil-navigator"></i>
                    </button>
                </div>

        </form>

    </div>



    <script>
    function cancelRegistration() {
        console.log("Cancel Registration function called");
        window.location.href = 'courseTable.php';
    }
    </script>

</body>

</html>