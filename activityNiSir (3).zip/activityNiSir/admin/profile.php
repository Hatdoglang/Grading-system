<?php

include("databse/dbcon.php");
session_start();

$fullname = ""; // Default value
$userType = ""; // Default value
$username = "";
// Check if the user is logged in
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] === true) {
    $loggedin = true;
    $id = $_SESSION['userId']; // Assuming you store user ID in the session

    // Fetch user data from the database
    $sql = "SELECT * FROM users WHERE id='$id'";
    $result = mysqli_query($con, $sql); // Use the $con variable for the database connection

    if ($result) {
        $row = mysqli_fetch_assoc($result);
        if ($row) {
            $userId = $row['id'];
            $fullname = $row['Namess'];
            $username = $row['usernamess'];
            $userType = $row['userType'];

            if ($userType == 0) {
                $userType = "User";
            } else {
                $userType = "Admin";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">

    <!-- Optional theme -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap-theme.min.css">

    <link rel="stylesheet" href="css/profile.css">
    <title>Profile</title>
</head>

<body>

<div style="margin-top: 40px;" class="container">
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
            <div class="well profile">
                <a href="javascript:void(0);" class="logo" onclick="toggleUserProfile();">
                    <h3 class="name pull-left clearfix"><?php echo "($userType) $fullname"; ?></h3>
                </a>
                <div class="clearfix"></div>
                <ul class="nav nav-tabs">
                    <li class="active">
                        <a href="#tab2" data-toggle="tab">Account</a>
                    </li>
                </ul>
                <div style="margin-top: 40px;" class="tab-pane" id="tab2">
                    <div class="row">
                        <div class="col-xs-12 col-sm-10 col-md-10 col-lg-10">
                            <div class="tab-content">
                                <div class="tab-pane active" id="basic">
                                    <form class="form-horizontal" role="form">
                                        <div class="form-group">
                                            <label for="usernamess" class="col-lg-2 control-label">User Name</label>
                                            <div class="col-lg-10">
                                                <input type="text" name="usernamess" class="form-control" id="usernamess" placeholder="<?php echo $username; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="Namess" class="col-lg-2 control-label">Full Name</label>
                                            <div class="col-lg-10">
                                                <input type="text" name="Namess" class="form-control" id="Namess" value="<?php echo $fullname; ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <a style="text-align: center; text-decoration: none;" href="dashboard.php" class="submit-btn">BACK</a>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


</body>
</html>
