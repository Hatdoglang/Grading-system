<style>
.report-container {
    position: relative;

}

.recent-Articles {
    margin-left: 60vh;
    margin-top: 100px;
}

/* Add this CSS to style the search bar */
button[type="submit"] {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

label {
    margin-bottom: 8px;
}

input,
select {
    margin-bottom: 16px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.action-buttons {
    display: flex;
    background: transparent;
    /* Adjust the margin as needed */
}

.action-button {
    background-color: transparent;
    cursor: pointer;
}

.action-button i {
    display: flex;
    font-size: 20px;
}

/* Adjustments for the table */
.data-table td form {
    display: flex;
}

input[type="hidden"] {
    display: none;
}

.styled-form {
    position: relative;
    display: inline-block;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.styled-form label {
    display: block;
    margin-bottom: 8px;
}

.styled-form input,
.styled-form select {
    width: 100%;
    padding: 8px;
    margin-bottom: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.styled-form button {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.data-table {
    margin-top: -290px;
    width: 600px;
    margin-left: 360px;
    border-radius: 10px;
    position: relative;

}

.edit-form-container {
    display: none;
    position: fixed;
    top: 30%;
    left: 50%;
    width: 400px;
    transform: translate(-50%, -50%);
    background-color: white;
    padding: 20px;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

.edit-form-container h2 {
    text-align: center;
    margin-bottom: 15px;
}

.edit-form-container label {
    margin-bottom: 8px;
    display: inline-block;
}

.edit-form-container label input,
.edit-form-container label select {
    width: 100%;
    /* Make inputs fill the entire width */
    padding: 8px;
    margin-top: 4px;
    /* Adjust spacing between label and input */
    border: 1px solid #ccc;
    border-radius: 5px;
}

.edit-form-container button {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

/* Additional styling for the "Close" button */
.edit-form-container .close-button {
    background-color: #ccc;
    color: #333;
    margin-top: 10px;
}


.edit-form-container select.edit-status {
    /* Add your styling for the select with the class "edit-status" here */
    width: 190px;
    padding: 8px;
    margin-left: 54px;
    display: inline-block;
    margin-top: 4px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* If you want to style the arrow, you can use the following */
.edit-form-container select.edit-status::-ms-expand,
.edit-form-container select.edit-status {
    appearance: none;
    background: url('path-to-arrow-image') no-repeat right #fff;
    background-size: 20px;
}
</style>