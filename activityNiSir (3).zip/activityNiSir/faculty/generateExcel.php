<?php
session_start();
include("../admin/databse/dbcon.php");
require_once 'phpspreadsheet/vendor/autoload.php';
include 'functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    echo "User not logged in.";
    exit();
}

$user_id = $_SESSION['user_id'];

// Check if the Student ID is provided in the URL
if (!isset($_GET['student_id']) || empty($_GET['student_id'])) {
    echo "Student ID not provided.";
    exit();
}

$student_id = $_GET['student_id'];

// Query to get student details
$student_query = "SELECT * FROM student WHERE id = '$student_id' AND facultyfk = '$user_id'";
$student_result = mysqli_query($con, $student_query);

if (!$student_result || mysqli_num_rows($student_result) == 0) {
    echo "Error: Student data not found.";
    exit();
}

$student_data = mysqli_fetch_assoc($student_result);

// Create a new PhpSpreadsheet instance
$spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set headers
$headers = ['Id Number', 'Last Name', 'First Name', 'Course', 'Year Lvl', 'Semester', 'Student Mark', 'Time', 'Remarks'];
$sheet->fromArray($headers, NULL, 'A1');

// Calculate remarks based on grades
$remarks = getPassOrFail($student_data['mark']);

// Add data to the spreadsheet
$sheet->setCellValue('A2', $student_data['idnumber']);
$sheet->setCellValue('B2', $student_data['lname']);
$sheet->setCellValue('C2', $student_data['fname']);
$sheet->setCellValue('D2', $student_data['course']);
$sheet->setCellValue('E2', $student_data['yearLvl']);
$sheet->setCellValue('F2', $student_data['semester']);
$sheet->setCellValue('G2', $student_data['mark']);
$sheet->setCellValue('H2', $student_data['time']);
$sheet->setCellValue('I2', $remarks);

// Save the Excel file
$filename = 'student_report.xlsx';
$writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
$writer->save($filename);

// Download the Excel file
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer->save('php://output');

exit();
?>
