<?php
session_start();
include("../admin/databse/dbcon.php");

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM student WHERE id = '$user_id'";
$result = mysqli_query($con, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);

  
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<style>
body {
    background-color: #f4f4f4;
    margin: 0;
}

.dashboard {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

.info-container {
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.label {
    font-weight: bold;
}

header {
    width: 100%;
    position: relative;
    height: 88px;
    background-color: white;
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    align-items: center;
    box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
}

.logo {
    font-size: 11px;
    font-weight: 600;
    color: #576cbc;
    margin-left: 20px;
    display: flex;
    align-items: center;
}

.logo h1 {
    color: #576cbc;
}

.hamburger {
    display: flex;
}

.nav-bar ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
}

.nav-bar ul li {
    margin-right: 95px;
}

.nav-bar ul a {
    text-decoration: none;
    display: flex;
    position: absolute;
    margin-top: -10px;
    color: #576cbc;
    font-size: 18px;
    margin-left: 795px;
    transition: .2s;
}
</style>

<body>
    <header>
        <div class="logo">
            <div class="hamburger">
                <h1>Welcome, <?php echo $user_data['fname'] . ' ' . $user_data['lname']; ?>!</h1>
            </div>

            <nav class="nav-bar">
                <ul>
                    <li><a href="dashboard.php" class="active">Home</a></li>
                    <li><a href="profile.php" class="active">Profile</a></li>
                    <li><a href="studentGrade.php" class="active">Grade</a></li>
                    <li><a href="login.php" class="active">Logout</a></li>

                </ul>
                </ul>
            </nav>

        </div>
    </header>

    <div class="dashboard">
        <h1>Dashboard</h1>

        <!-- Display raw yearLvl and semester from student table -->
        <div class="info-container">
            <div class="info-item">
                <span class="label">ID Number:</span>
                <span><?php echo $user_data['idnumber']; ?></span>
            </div>
            <div class="info-item">
                <span class="label">Full Name:</span>
                <span><?php echo $user_data['lname'] . '&nbsp;&nbsp; ' . $user_data['fname']; ?></span>
            </div>
            <div class="info-item">
                <span class="label">Year Level:</span>
                <span><?php echo $user_data['yearLvl']; ?></span>
            </div>
            <div class="info-item">
                <span class="label">Semester:</span>
                <span><?php echo $user_data['semester']; ?></span>
            </div>
        </div>

        <!-- Display subjectfk value from subject table -->

    </div>
</body>

</html>