<?php
function getPassOrFail($grade) {
    if ($grade >= 1 && $grade <= 3) {
        return "Pass";
    } elseif ($grade >= 3.5 && $grade <= 5) {
        return "Fail";
    } else {
        return "N/A";
    }
}

function getPassOrFailClass($grade) {
    if ($grade >= 1 && $grade <= 3) {
        return "pass";
    } elseif ($grade >= 3.5 && $grade <= 5) {
        return "fail";
    } else {
        return "n/a";
    }
}
?>
