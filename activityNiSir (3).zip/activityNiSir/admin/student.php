<?php
include("index.php");
include("databse/dbcon.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    // Get form input data and use prepared statements to insert data
    $IDnumber = $_POST['idnumber'] ?? "";
    $firstname = $_POST['fname'] ?? "";
    $lastname = $_POST['lname'] ?? "";
    $middlename = $_POST['mname'] ?? "";
    $dob = $_POST['dob'] ?? "";
    $gender = $_POST['gender'] ?? "";
    $institute = $_POST['institute'] ?? "";
    $course = $_POST['course'] ?? "";
    $studentNo = $_POST['student_contact'] ?? "";
    $province = $_POST['province'] ?? "";
    $municipality = $_POST['municipality'] ?? "";
    $barangay = $_POST['barangay'] ?? "";
    $purok = $_POST['purok'] ?? "";
    $zipcode = $_POST['zipcode'] ?? "";
    $guardian = $_POST['guardian'] ?? "";
    $contactnumber = $_POST['contnumber'] ?? "";
    $address = $_POST['address'] ?? "";
    $facultyfk = $_POST['facultyfk'] ?? "";
    $subjectfk = $_POST['subjectfk'] ?? "";
    $yearLvl =  $_POST['yearLvl'] ?? "";
    $semester =  $_POST['semester'] ?? "";


    if (empty($IDnumber) || empty($firstname) || empty($lastname)) {
        echo "<script type='text/javascript'> alert('Please fill in all required fields')</script>";
    } else {
        $query = "INSERT INTO student (idnumber, fname, lname, mname, dob, gender, institute, course, student_contact, province, municipality, barangay, purok, zipcode, guardian, contnumber, address, facultyfk,  yearLvl, semester) VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? ,? ,?)";
        $stmt = mysqli_prepare($con, $query);

        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "ssssssssssssssssssss", $IDnumber, $firstname, $lastname, $middlename, $dob, $gender, $institute, $course, $studentNo, $province, $municipality, $barangay, $purok, $zipcode, $guardian, $contactnumber, $address, $facultyfk,  $yearLvl, $semester);

            if (mysqli_stmt_execute($stmt)) {
                echo "<script type='text/javascript'> alert('Registration Successfully'); window.location.href = 'studenttable.php'; </script>";
                exit();
            } else {
                echo "<script type='text/javascript'> alert('Registration Error')</script>";
                echo "MySQL Error: " . mysqli_error($con);
            }

            mysqli_stmt_close($stmt);
        } else {
            echo "Error in preparing the SQL statement.";
        }

        mysqli_close($con);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <title>Student Registration Form</title>
    <link rel="stylesheet" href="css/studen.css">

    <style>
    @import url("https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap");

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .container {
        position: relative;
        max-width: 900px;
        width: 100%;
        border-radius: 6px;
        padding: 30px;
        margin: 0 15px;
        background-color: #fff;
        box-shadow: 0 5px 10px rgba(0, 0, 0, 0.1);
    }

    .container header {
        position: relative;
        font-size: 20px;
        font-weight: 600;
        color: #333;
    }

    .container header::before {
        content: "";
        position: absolute;
        bottom: -2px;
        height: 3px;
        width: 80px;
        border-radius: 8px;
        background-color: #4070f4;
    }


    .container form {
        position: relative;
        margin-top: 16px;
        min-height: 490px;
        background-color: #fff;
        overflow: hidden;

    }

    .container form .form {
        position: absolute;
        background-color: #fff;
        transition: 0.3s ease;
    }

    .container form .form.second {
        opacity: 0;
        pointer-events: none;
        transform: translateX(100%);
    }

    form.secActive .form.second {
        opacity: 1;
        pointer-events: auto;
        transform: translateX(0);
    }

    form.secActive .form.first {
        opacity: 0;
        pointer-events: none;
        transform: translateX(-100%);
    }


    .container form .details {
        margin-top: 30px;
    }

    .container form.guardian {
        margin-top: 30px;
    }

    .container form .title {
        display: flex;
        margin-bottom: 8px;
        font-size: 16px;
        font-weight: 500;
        margin: 6px 0;
        color: #333;
    }

    .container form .fields {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
    }

    .container .fields .input-fields {
        display: flex;
        width: calc(100% / 3 - 15px);
        flex-direction: column;
        margin: 4px 0;
    }

    .input-fields input,
    .input-fields select {
        outline: none;
        height: 39px;
        padding: 0 15px;
        font-size: 14px;
        color: #333;
        font-weight: 500;
        width: 100%;
        border: 1px solid #aaa;
        border-radius: 5px;
        margin: 8px 0;
    }

    .input-fields input:focus,
    .input-fields input:valid,
    .input-fields select:focus,
    .input-fields select:valid {
        box-shadow: 0 3px 6px rgba(0, 0, 0, 0.13);
    }

    .input-fields input[type="date"] {
        color: #707070;
    }

    .input-fields input[type="date"]:valid {
        color: #333;
    }

    .container form button,
    .bacckBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 90%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container form button,
    .bacckBtn {
        font-size: 16px;
        font-weight: 400;
    }

    form button:hover {
        background-color: #265df2;
    }

    form button i,
    form .bacckBtn i {
        margin: 0 6px;
    }

    form .bacckBtn i {
        transform: rotate(180deg);
    }

    form .buttons {
        display: flex;
        align-items: center;
    }

    form .buttons button,
    .bacckBtn {
        margin-right: 14px;
    }

    /* Modal styles */
    .modal {
        display: none;
        position: fixed;
        z-index: 1;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        overflow: auto;
        background-color: rgba(0, 0, 0, 0.4);
    }

    .modal-content {
        background-color: #fefefe;
        margin: 15% auto;
        padding: 20px;
        border: 1px solid #888;
        width: 80%;
    }

    .close {
        color: #aaa;
        float: right;
        font-size: 28px;
        font-weight: bold;
    }

    .close:hover,
    .close:focus {
        color: black;
        text-decoration: none;
        cursor: pointer;
    }
    </style>
</head>

<body>
    <div style="margin-top: 40px;" class="container">
        <header>Registration</header>
        <form action="student.php" method="POST">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Personal Details</span>
                    <div class="fields">
                        <div class="input-fields">
                            <label>ID Number</label>
                            <input type="text" name="idnumber" placeholder="Enter ID Number" required>
                        </div>

                        <div class="input-fields">
                            <label>First Name</label>
                            <input type="text" name="fname" placeholder="Enter First Name" required>
                        </div>

                        <div class="input-fields">
                            <label>Last Name</label>
                            <input type="text" name="lname" placeholder="Enter Last Name" required>
                        </div>

                        <div class="input-fields">
                            <label>Middle Name</label>
                            <input type="text" name="mname" placeholder="Enter Middle Name" required>
                        </div>

                        <div class="input-fields">
                            <label>Date of Birth</label>
                            <input type="date" name="dob" placeholder="Enter Date of Birth" required>
                        </div>

                        <div class="input-fields">
                            <label>Gender</label>
                            <select name="gender" required>
                                <option value="" disabled selected>Select Gender</option>
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                            </select>
                        </div>

                        <div class="input-fields">
                            <label for="institute">Institute</label>
                            <select name="institute" required>
                                <option value="" disabled selected>Select Institute</option>

                                <?php
                                $sql = "SELECT InstituteName FROM institute";
                                $result = $con->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                        echo '<option value="' . $row["InstituteName"] . '">' . $row["InstituteName"] . '</option>';
                                    }
                                } else {
                                    echo '<option value="" disabled>No institutes found</option>';
                                }
                                ?>
                            </select>
                        </div>
                        <div class="input-fields">
                            <label>Course</label>
                            <select name="course" required>
                                <option value="" disabled selected>Select Course</option>
                                <?php
                                $sql = "SELECT N_Course FROM courses";
                                $result = $con->query($sql);

                                if ($result->num_rows > 0) {
                                    while ($rowOption = $result->fetch_assoc()) {
                                        echo '<option value="' . $rowOption["N_Course"] . '">' . $rowOption["N_Course"] . '</option>';
                                    }
                                } else {
                                    echo '<option value="" disabled>No courses found</option>';
                                }
                                ?>
                            </select>
                        </div>



                        <div class="input-fields">
                            <label>Student No.</label>
                            <input type="text" name="student_contact" placeholder="Enter Contact No." required>
                        </div>


                    </div>
                    <div class="buttons">
                        <div class="bacckBtn" onclick="cancelRegistration()">
                            <i class="uil uil-navigator"></i>
                            <span class="btntext">Cancel</span>
                        </div>
                        <button class="nextBtn">
                            <span class="btnnext">Next</span>
                            <i class="uil uil-navigator"></i>
                        </button>
                    </div>
                </div>
            </div>
            <div class="form second">
                <div class="details address">
                    <span class="title">Address Detials</span>
                    <div class="fields">
                        <div class="input-fields">
                            <label>Province</label>
                            <input type="text" name="province" placeholder="Enter Province" required>
                        </div>

                        <div class="input-fields">
                            <label>Municipality</label>
                            <input type="text" name="municipality" placeholder="Enter Municipality" required>
                        </div>

                        <div class="input-fields">
                            <label>Barangay</label>
                            <input type="text" name="barangay" placeholder="Enter Barangay" required>
                        </div>
                        <div class="input-fields">
                            <label>Purok</label>
                            <input type="text" name="purok" placeholder="Enter Purok" required>
                        </div>


                        <div class="input-fields">
                            <label>Zip Code</label>
                            <input type="text" name="zipcode" placeholder="Enter Zip Code" required>
                        </div>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    </div>
                    <div class="details guardian">
                        <span class="title">Guardian Detials</span>
                        <div class="fields">
                            <div class="input-fields">
                                <label>Name of Guardian</label>
                                <input type="text" name="guardian" placeholder="Enter Province" required>
                            </div>

                            <div class="input-fields">
                                <label>Guardian No.</label>
                                <input type="text" name="contnumber" placeholder="Enter Municipality" required>
                            </div>

                            <div class="input-fields">
                                <label>Address</label>
                                <input type="text" name="address" placeholder="Enter Barangay" required>
                            </div>
                        </div>
                    </div>
                    <div id="myModal" class="modal">
                        <div class="modal-content">
                            <span class="close" onclick="closeModal()">&times;</span>
                            <!-- Content of the pop-up box -->
                            <h2>Assigned to Student</h2>
                            <div class="input-fields">
                                <label for="faculty">Assigned to Student</label>
                                <select name="facultyfk" required>
                                    <option value="" disabled selected>Select Faculty</option>
                                    <?php
                                    $sql = "SELECT id, f_name, l_name FROM faculty";
                                    $result = $con->query($sql);

                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<option value="' . $row["id"] . '">' . $row["f_name"] . ' ' . $row["l_name"] . '</option>';
                                        }
                                    } else {
                                        echo '<option value="" disabled>No faculty members found</option>';
                                    }
                                ?>
                                </select>
                            </div>
                            <div class="input-fields">
                                <label>Year Level</label>
                                <select name="yearLvl" required>
                                    <option value="" disabled selected>Select Year Level</option>
                                    <option value="First Year">First Year</option>
                                    <option value="Second Year">Second Year</option>
                                    <option value="Third Year">Third Year</option>
                                    <option value="Fourth Year">Fourth Year</option>
                                    <!-- Add more options as needed -->
                                </select>
                            </div>
                            <div class="input-fields">
                                <label>Semester</label>
                                <select name="semester" required>
                                    <option value="" disabled selected>Select Semester</option>
                                    <option value="First Semester">First Semester</option>
                                    <option value="Second Semester">Second Semester</option>
                                    <option value="Summer">Summer</option>
                                </select>
                            </div>
                            <!-- Other fields for Year Level and Semester -->
                            <div class="buttons">
                                <button class="nextBtn" onclick="closeModal()">Close</button>
                            </div>
                        </div>
                    </div>

                    <div class="buttons">
                        <div class="backBtn">
                            <i class="uil uil-navigator"></i>
                            <span class="btntext">Back</span>
                        </div>
                        <button class="backBtn" onclick="showAssignedSection()">
                            <span class="btntext">Assigned</span>
                        </button>
                        <button class="nextBtn">
                            <span class="btntext">Submit</span>
                            <i class="uil uil-navigator"></i>
                        </button>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var form = document.getElementById('registrationForm');
        form.addEventListener('submit', function(event) {
            event.preventDefault();
            var formData = getFormDataFromActiveSection();
            submitFormData(formData);
        });
    });

    function getFormDataFromActiveSection() {
        var activeSection = document.querySelector('.form.secActive');
        if (activeSection.classList.contains('first')) {
            return getFormDataFromFirstSection();
        } else if (activeSection.classList.contains('second')) {
            return getFormDataFromSecondSection();
        }
        return {};
    }

    function submitFormData(formData) {
        console.log('Form data to be submitted:', formData);

        // Example: Using AJAX for form submission
        // Replace this with your actual AJAX code
        // ajaxSubmit(formData);

        // Close the modal after submitting the form
        closeModal();
    }

    function showAssignedSection() {
        var modal = document.getElementById("myModal");
        modal.style.display = "block";
    }

    function closeModal() {
        var modal = document.getElementById("myModal");
        modal.style.display = "none";
    }

    function cancelRegistration() {
        console.log("Cancel Registration function called");
        window.location.href = 'studenttable.php';
    }
    </script>


    <script src="js/script.js"></script>
    <script>
    function cancelRegistration() {
        console.log("Cancel Registration function called");
        window.location.href = 'studenttable.php';
    }
    </script>
</body>

</html>