<?php
session_start();
include("../admin/databse/dbcon.php");

if (isset($_GET['student_id']) && isset($_GET['new_mark'])) {
    $studentId = $_GET['student_id'];
    $newMark = $_GET['new_mark'];

    // Update the mark in the database
    $updateMarkQuery = "UPDATE student SET mark = '$newMark' WHERE id = '$studentId'";
    $updateMarkResult = mysqli_query($con, $updateMarkQuery);

    if ($updateMarkResult) {
        // Successfully updated mark
        echo json_encode(['success' => true]);
        exit();
    } else {
        // Failed to update mark
        echo json_encode(['success' => false, 'error' => mysqli_error($con)]);
        exit();
    }
} else {
    // Invalid request
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
    exit();
}
?>
