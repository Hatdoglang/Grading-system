<?php
session_start();
include("../admin/databse/dbcon.php");

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Query to get data about the logged-in user from the faculty table
$faculty_query = "SELECT * FROM faculty WHERE id = '$user_id'";
$faculty_result = mysqli_query($con, $faculty_query);

if (!$faculty_result || mysqli_num_rows($faculty_result) == 0) {
    echo "Error: User data not found";
    exit();
}

$user_data = mysqli_fetch_assoc($faculty_result);

// Query to get the subjects handled by the faculty
$subjects_query = "SELECT * FROM subjects WHERE facultyfk= '$user_id'";
$subjects_result = mysqli_query($con, $subjects_query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/dashboard.css">

    <title>Dashboard</title>
</head>

<style>
/* Your existing styles remain unchanged */
body {
    background-color: #f4f4f4;
    margin: 0;
}

.dashboard {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    margin-top: 100px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    margin-right: 90px;
    color: #333;
}

.info-container {
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.label {
    font-weight: bold;
}




header {
    width: 100%;
    position: relative;
    height: 88px;
    background-color: white;
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    align-items: center;
    box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
}

.logo {
    font-size: 11px;
    font-weight: 600;
    color: #576cbc;
    margin-left: 20px;
    display: flex;
    align-items: center;
}

.logo h1 {
    color: #576cbc;
}

.hamburger {
    display: flex;
}


.nav-bar ul {
    display: flex;
    list-style: none;
    margin: 5px;
    padding: 5px;
}

.nav-bar ul li {
    display: flex;
    margin-right: 95px;

}

.nav-bar ul a {
    text-decoration: none;
    display: flex;
    position: absolute;
    margin-top: -10px;
    color: #576cbc;
    font-size: 18px;
    margin-left: 650px;
    transition: .2s;
}

.list a {
    color: #fff;
    background: #5500cb;
    height: 45px;
    width: 160px;
    font-size: 18px;
    border-radius: 5px;
    cursor: pointer;
}

/* Add your new styles here */
.subject-container {
    margin-top: 20px;
}

.subject-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.view-small-btn {
    background-color: #576cbc;
    color: #fff;
    padding: 5px 10px;
    border-radius: 3px;
    text-decoration: none;
}

.subject-container {
    margin-top: 20px;
}

.subject-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.view-small-btn {
    background-color: #576cbc;
    color: #fff;
    padding: 5px 10px;
    border-radius: 3px;
    text-decoration: none;
}

.student-count {
    margin-left: 20px;
    font-weight: bold;
}
</style>

<body>
    <!-- Your existing HTML remains unchanged -->
    <header>
        <div class="logo">
            <div class="hamburger">
                <h1>Welcome, <?php echo $user_data['f_name'] ?>!</h1>
            </div>

            <nav class="nav-bar">
                <ul>
                    <li><a href="dashboard.php" class="active">Home</a></li>
                    <li><a href="student.php" class="active">Students</a></li>
                    <li><a href="Grade.php" class="active">Grade</a></li>
                    <li><a href="Report.php" class="active">Report</a></li>


                    <li><a href="login.php" class="active">Logout</a></li>

                </ul>
                </ul>
            </nav>

        </div>
    </header>
    <div class="dashboard">
        <h1>Subjects handled by <?php echo $user_data['f_name'] ?>!</h1>

        <div class="subject-container">
            <?php
        while ($subject = mysqli_fetch_assoc($subjects_result)) {
            // Query to count the number of students for each subject
            $subject_id = $subject['id'];
            $count_query = "SELECT COUNT(*) AS idnumber FROM student WHERE subjectfk = '$subject_id'";
            $count_result = mysqli_query($con, $count_query);
            $count_data = mysqli_fetch_assoc($count_result);

            echo '<div class="subject-item">';
            echo '<span class="label">Subject:</span> ' . $subject['code'];
            echo '<span class="student-count">Total Students: ' . $count_data['idnumber'] . '</span>';
            echo '<a href="Subject.php?Subject_id=' . $subject_id . '" class="view-small-btn">View</a>';
            echo '</div>';
        }
        ?>
        </div>
    </div>

</body>

</html>