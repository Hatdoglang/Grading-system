<?php
include("index.php");
include("databse/dbcon.php");

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_school_year'])) {
    $schoolyear = $_POST['schoolyear'];
    $semester = $_POST['semester'];
    $status = $_POST['status'];

    $sql = "INSERT INTO schoolyear (school_year, Semester, status) VALUES ('$schoolyear', '$semester', '$status')";

    if (mysqli_query($con, $sql)) {
        // Success message or redirect to a success page
        echo "School year added successfully.";
        header("Location: {$_SERVER['PHP_SELF']}"); // Redirect to the same page to prevent form resubmission
        exit();
    } else {
        // Error message or redirect to an error page
        echo "Error: " . mysqli_error($con);
    }
}

// Assuming you have a query to retrieve school years, adjust as needed
$query = "SELECT * FROM schoolyear";
$schoolyeart_result = mysqli_query($con, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
        integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="stylesheet" href="css/dashboard.css">
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        setTimeout(function() {
            var successMessage = document.querySelector('.success-message');
            if (successMessage) {
                successMessage.style.display = 'none';
            }
        }, 2000); // 5000 milliseconds = 5 seconds
    });
    </script>
    <script>
    function closeEditForm() {
        document.getElementById('edit-form').style.display = 'none';
    }

    // This function is an example, you need to adapt it based on your requirements
    function updateSchoolYear() {
        // Fetch the edited data and update the record in the database
        var schoolYearId = document.getElementById('edit-school-year-id').value;
        var editedSchoolYear = document.getElementById('edit-schoolyear').value;
        var editedSemester = document.getElementById('edit-semester').value;
        var editedStatus = document.getElementById('edit-status').value;

        // Use AJAX or other methods to update the record
        // ...

        // After updating, you can hide the edit form
        closeEditForm();
    }

    // Your existing JavaScript code
    function editSchoolYear(schoolYearId) {
        // Fetch the current record's data using AJAX or other methods
        // For simplicity, I'll assume you have JavaScript variable 'data' with the record data

        // Display the edit form
        document.getElementById('edit-form').style.display = 'block';

        // Populate the edit form fields with the current record's data
        document.getElementById('edit-school-year-id').value = schoolYearId;
        // Populate other form fields as needed
    }
    </script>
</head>
<style>
.report-container {
    position: relative;

}

.recent-Articles {
    margin-left: 60vh;
    margin-top: 100px;
}

/* Add this CSS to style the search bar */
button[type="submit"] {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

label {
    margin-bottom: 8px;
}

input,
select {
    margin-bottom: 16px;
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

button {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.action-buttons {
    display: flex;
    background: transparent;
    /* Adjust the margin as needed */
}

.action-button {
    background-color: transparent;
    cursor: pointer;
}

.action-button i {
    display: flex;
    font-size: 20px;
}

/* Adjustments for the table */
.data-table td form {
    display: flex;
}

input[type="hidden"] {
    display: none;
}

.styled-form {
    position: relative;
    display: inline-block;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.styled-form label {
    display: block;
    margin-bottom: 8px;
}

.styled-form input,
.styled-form select {
    width: 100%;
    padding: 8px;
    margin-bottom: 16px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.styled-form button {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

.data-table {
    margin-top: -330px;
    width: 600px;
    margin-left: 360px;
    border-radius: 10px;
    position: relative;

}

.edit-form-container {
    display: none;
    position: fixed;
    top: 30%;
    left: 50%;
    width: 400px;
    transform: translate(-50%, -50%);
    background-color: white;
    padding: 20px;
    border: 1px solid #ccc;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    z-index: 1000;
}

.edit-form-container h2 {
    text-align: center;
    margin-bottom: 15px;
}

.edit-form-container label {
    margin-bottom: 8px;
    display: inline-block;
}

.edit-form-container label input,
.edit-form-container label select {
    width: 100%;
    /* Make inputs fill the entire width */
    padding: 8px;
    margin-top: 4px;
    /* Adjust spacing between label and input */
    border: 1px solid #ccc;
    border-radius: 5px;
}

.edit-form-container button {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

/* Additional styling for the "Close" button */
.edit-form-container .close-button {
    background-color: #ccc;
    color: #333;
    margin-top: 10px;
}


.edit-form-container select.edit-status {
    /* Add your styling for the select with the class "edit-status" here */
    width: 190px;
    padding: 8px;
    margin-left: 54px;
    display: inline-block;
    margin-top: 4px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.edit-form-container select.edit-semester {
    width: 188px;
    padding: 8px;
    margin-left: 32px;
    display: inline-block;
    margin-top: 4px;
    margin-bottom: -20px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

/* If you want to style the arrow, you can use the following */
.edit-form-container select.edit-status::-ms-expand,
.edit-form-container select.edit-status {
    appearance: none;
    background: url('path-to-arrow-image') no-repeat right #fff;
    background-size: 20px;
}
</style>

<body>
    <div class="main">
        <div style="margin-left:35vh; margin-top:-100px;" class="report-container">
            <div class="report-header">
                <h1 class="recent-Articles">School Year</h1>
            </div>
            <div class="report-body">
                <form method="post" class="styled-form">
                    <label for="schoolyear">School Year:</label>
                    <input type="text" name="schoolyear" required>

                    <label for="semester">Semester:</label>
                    <select name="semester" required>
                        <option value="" disabled selected>Choose Semester</option>
                        <option value="1st">1st</option>
                        <option value="2nd">2nd</option>
                        <option value="Summer">Summer</option>
                    </select>

                    <label for="status">Status:</label>
                    <select name="status" required>
                        <option value="" disabled selected>Choose Semester</option>

                        <option value="active">Active ✅</option>
                        <option value="inactive">Inactive ❌</option>
                    </select>

                    <button type="submit" name="add_school_year">Add School Year</button>
                </form>

                <table class="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>School Year</th>
                            <th>Semester</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($schoolyeart_result)): ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['school_year']; ?></td>
                            <td><?php echo $row['Semester']; ?></td>
                            <td>
                                <?php if (isset($row['status'])): ?>
                                <?php if ($row['status'] == 'active'): ?>
                                <i class="fas fa-check" style="color: #27ae60;"></i> <!-- Check icon for active -->
                                <?php else: ?>
                                <i class="fas fa-times" style="color: #e74c3c;"></i> <!-- X icon for inactive -->
                                <?php endif; ?>
                                <?php else: ?>
                                <!-- Handle case where 'status' key is not present -->
                                Status not available
                                <?php endif; ?>
                            </td>

                            <!-- Inside the loop where you display school year records -->
                            <td>
                                <form method="post" class="action-buttons-container">
                                    <div class="action-buttons">
                                        <label for="update_school_year" class="action-button"
                                            onclick="editSchoolYear(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-edit" style="color: #3498db;"></i>
                                        </label>
                                        <label for="remove_school_year" class="action-button"
                                            onclick="confirmDelete(<?php echo $row['id']; ?>)">
                                            <i class="fas fa-trash-alt" style="color: #e74c3c;"></i>
                                        </label>
                                    </div>
                                    <input type="hidden" name="school_year_id" value="<?php echo $row['id']; ?>">
                                </form>
                            </td>

                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
            <div id="not-found-message" style="display: none; margin-left: 400px; font-size: 20px; color: red;">No
                matching results found.</div>
        </div>
    </div>

    <!-- Edit form directly in the main HTML file -->
    <div class="edit-form-container" id="edit-form">
        <h2 id="edit-form-header">Edit School Year</h2>
        <form method="post" id="update-form">
            <input type="hidden" name="school_year_id" id="edit-school-year-id">
            <label for="edit-schoolyear">School Year:</label>&nbsp;&nbsp;&nbsp;
            <input type="text" name="edit-schoolyear" id="edit-schoolyear" required>
            <br>
            <label for="Semester">Semester:</label>
            <select class="edit-semester" name="Semester" id="edit-semester">
                <option value="" disabled selected>Choose Semester</option>
                <option value="1st">1st</option>
                <option value="2nd">2nd</option>
                <option value="Summer">Summer</option>
            </select>
            <br>

            <br>
            <label class="edit-label" for="edit-status">Status:</label>
            <select class="edit-status" name="status" id="edit-status" required>
                <option value="" disabled selected>Choose Status</option>

                <option value="active">Active ✅</option>
                <option value="inactive">Inactive ❌</option>
            </select>
            <br>
            <button type="button" onclick="updateSchoolYear()">Update</button>
            <button type="button" onclick="closeEditForm()">Close</button>
        </form>
    </div>
    <script>
    function confirmDelete(schoolYearId) {
        var result = confirm("Are you sure you want to delete this school year?");
        if (result) {
            window.location.href = 'deleteschoolyear.php?id=' + schoolYearId;
        }
    }
    </script>
    <script>
    function editSchoolYear(schoolYearId) {

        // Display the edit form
        document.getElementById('edit-form').style.display = 'block';

        document.getElementById('edit-school-year-id').value = schoolYearId;
    }
    </script>
    <script>
    // Function to make the edit box movable
    function makeMovable(element) {
        var pos1 = 0,
            pos2 = 0,
            pos3 = 0,
            pos4 = 0;
        if (document.getElementById(element.id + "-header")) {
            // if present, the header is where you move the DIV from:
            document.getElementById(element.id + "-header").onmousedown = dragMouseDown;
        } else {
            // otherwise, move the DIV from anywhere inside the DIV:
            element.onmousedown = dragMouseDown;
        }

        function dragMouseDown(e) {
            e = e || window.event;
            e.preventDefault();
            // get the mouse cursor position at startup:
            pos3 = e.clientX;
            pos4 = e.clientY;
            document.onmouseup = closeDragElement;
            // call a function whenever the cursor moves:
            document.onmousemove = elementDrag;
        }

        function elementDrag(e) {
            e = e || window.event;
            e.preventDefault();
            // calculate the new cursor position:
            pos1 = pos3 - e.clientX;
            pos2 = pos4 - e.clientY;
            pos3 = e.clientX;
            pos4 = e.clientY;
            // set the element's new position:
            element.style.top = (element.offsetTop - pos2) + "px";
            element.style.left = (element.offsetLeft - pos1) + "px";
        }

        function closeDragElement() {
            // stop moving when mouse button is released:
            document.onmouseup = null;
            document.onmousemove = null;
        }
    }

    // Make the edit form movable when the page loads
    document.addEventListener("DOMContentLoaded", function() {
        makeMovable(document.getElementById("edit-form"));
    });
    </script>

    <script>
    function updateSchoolYear() {
        var schoolYearId = document.getElementById('edit-school-year-id').value;
        var editedSchoolYear = document.getElementById('edit-schoolyear').value;
        var editedSemester = document.getElementById('edit-semester').value;
        var editedStatus = document.getElementById('edit-status').value;

        // Use AJAX to send data to the server for updating
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'update_school_year.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded'); // Updated content type
        xhr.onreadystatechange = function() {
            if (xhr.readyState === 4) {
                if (xhr.status === 200) {
                    // Handle the response from the server if needed
                    // For now, you can log the response to the console
                    console.log(xhr.responseText);

                    // After updating, you can hide the edit form
                    closeEditForm();

                    // Reload the page or update the displayed data as needed
                    window.location.reload(); // This reloads the page, adjust as needed
                } else {
                    // Handle the case where the server returns an error status
                    console.error('Error updating school year. Status: ' + xhr.status);
                }
            }
        };

        // Construct the data as a URL-encoded string
        var data = 'id=' + encodeURIComponent(schoolYearId) +
            '&school_year=' + encodeURIComponent(editedSchoolYear) +
            '&Semester=' + encodeURIComponent(editedSemester) +
            '&status=' + encodeURIComponent(editedStatus);

        // Send the request
        xhr.send(data);
    }
    </script>

</body>

</html>