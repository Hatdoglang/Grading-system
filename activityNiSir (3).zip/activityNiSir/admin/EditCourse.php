<?php

session_start(); // Start the session
include ("databse/dbcon.php");

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    // Check if the ID exists in the database
    $sql = "SELECT * FROM courses WHERE id = '$id'";
    $result = $con->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            // Handle the case where the ID does not exist in the database
            echo "Record not found.";
            exit();
        }
    } else {
        // Handle the case where the database query has an error
        echo "Database error: " . $con->error;
        exit();
    }
} else {
    // Handle the case where 'edit' parameter is not set in the URL
    echo "Invalid request.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Edit Form</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
    <style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Poppins', sans-serif;
    }

    body {
        width: 100%;
        background: #dfe9f5;
        display: flex;
        justify-content: center;
        align-items: center;
    }

    .registration-container {
        background: transparent;
        margin-top: 3%;
        padding: 3%;
        display: flex;
        justify-content: center;
        align-items: center;
        margin-top: 10px;
    }

    .details-section {

        margin-top: 30px;
        background: #fff;
        border-radius: 15px;
        height: 470px;
        width: 600px;
        box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: #495057;
    }

    .three-details-item {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }

    label {
        width: calc(33.33% - 20px);
        margin-bottom: 20px;
    }

    label p {
        margin-top: 60px;
        font-weight: 650;
        margin-bottom: 5px;
    }

    input {
        width: 300px;
        margin-left: 10px;
        height: 40px;
        border-radius: 5px;
        padding: 0 15px;


    }

    select {
        width: 90%;
        margin-left: 10px;
        height: 40px;
        border-radius: 5px;
        padding: 0 15px;


    }


    .container button,
    .backBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 100%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container button,
    .bacckBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 100%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container button,
    .container .backBtn {
        font-size: 16px;
        font-weight: 400;
    }

    .container button,
    .container .bacckBtn {
        font-size: 16px;
        font-weight: 400;
    }

    button:hover {
        background-color: #265df2;
    }





    .buttons {
        position: absolute;
        margin-top: 200px;
        width: 900px;
        display: flex;
        align-items: center;
    }

    .buttons button,
    .backBtn {
        margin-right: 14px;
    }

    form {
        margin: 0 90px;
    }

    form h4 {
        font-size: 20px;
        font-weight: 600;
    }

    .buttons button,
    .bacckBtn {
        margin-right: 14px;
    }
    </style>
    <section class="registration-container">
        <section class="details-section">
            <form action="updateCourse.php" method="post" class="registration-form" id="registration-form">
                <!-- Student Details Section -->
                <h2>Edit Course</h2>

                <section class="personal-details">

               

                    <label>
                        <p>Course Name</p>
                        <input type="text" name="N_Course" value="<?= $row['N_Course']; ?>" placeholder="Enter Course Name"
                            required>
                    </label>

                    <div class="bacckBtn" onclick="cancelRegistration()">
                        <i class="uil uil-navigator"></i>

                        <span class="btntext">Cancel</span>
                    </div>
                    <button style="margin-left:30vh; margin-top:-70px;" class="bacckBtn" type="submit" name="update">
                        <span class="bacckBtn">update</span>
                        <i class="uil uil-navigator"></i>
                    </button>
                </section>
            </form>
        </section>
    </section>

    </section>
</body>
<script>
function cancelRegistration() {
    console.log("Cancel Registration function called");
    window.location.href = 'courseTable.php';
}
</script>

</html>