<?php
session_start();

include("../admin/databse/dbcon.php");

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $idnumber = mysqli_real_escape_string($con, $_POST['idnumber']);
    $dob = mysqli_real_escape_string($con, $_POST['dob']);

    if (!empty($idnumber) && !empty($dob)) {
        $query = "SELECT * FROM student WHERE idnumber = '$idnumber' AND dob = '$dob' LIMIT 1";
        $result = mysqli_query($con, $query);

        if ($result && mysqli_num_rows($result) > 0) {
            $user_data = mysqli_fetch_assoc($result);

            // You can customize this part based on your database structure
            $_SESSION['user_id'] = $user_data['id'];
            $_SESSION['user_name'] = $user_data['name'];

            header("location: dashboard.php");
            die;
        } else {
            echo "<script type='text/javascript'> alert('Invalid Student ID or Date of Birth')</script>";
        }
    } else {
        echo "<script type='text/javascript'> alert('Please enter Student ID and Date of Birth')</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Login</title>
</head>
<style>
body {
    background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
    background-size: 400% 400%;
    animation: gradient 15s ease infinite;
}

@keyframes gradient {
    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}

.links {
    margin-top: 20px;
    font-size: 18px;
}
</style>

<body>
    <div class="wrapper">
        <form method="POST" action="" class="form">
            <h1 class="title">Student</h1>
            <div class="inp">
                <input type="text" name="idnumber" class="input" placeholder="Student ID">
                <i class="fa fa-user"></i>
            </div>
            <div class="inp">
                <input type="password" name="dob" id="password" class="input" placeholder="Password is your DOB">
                <span class="password-toggle" onclick="togglePasswordVisibility()"><i class="fa fa-eye"></i></span>
            </div>
            <button class="submit" type="submit" name="submit" value="Submit">Login</button>
            <div class="links">
                <a href="../index.php">Back to Home</a>
            </div>
        </form>
        <div></div>
        <div class="banner">
            <img style="border-radius:50%; height: 70px; width: 15%; position: absolute; margin-right:33px; margin-bottom: 22vh;"
                src="uploads/download.png" alt="">
            <h1 style="font-family:Baskerville Old Face; margin-top: 30px;" class="wel_text">Grading <br> System</h1>
        </div>
    </div>

    <script>
    function togglePasswordVisibility() {
        var passwordInput = document.getElementById("password");
        var passwordToggle = document.querySelector(".password-toggle");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            passwordToggle.innerHTML = '<i class="fa fa-eye-slash"></i>';
        } else {
            passwordInput.type = "password";
            passwordToggle.innerHTML = '<i class="fa fa-eye"></i>';
        }
    }
    </script>

</body>

</html>