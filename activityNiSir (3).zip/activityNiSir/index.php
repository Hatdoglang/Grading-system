<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- Include Font Awesome stylesheet -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <style>
    body {
        font-family: Arial, sans-serif;
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradient 15s ease infinite;
        height: 100vh;
        margin: 0;
    }

    .container {
        text-align: center;
    }

    h2 {
        font-size: 38px;
        font-weight: 900;
        position: relative;
        margin-bottom: 140px;
        color: white;
    }

    .button {
        position: relative;
        display: flex;
        flex-direction: column;
        align-items: center;
        background-color: transparent;
        border: 4px solid transparent;
        border-image: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        border-image-slice: 1;
        border-radius: 3px;
        color: white;
        padding: 55px 92px;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 24px;
        margin: 4px 10px 80px;
        cursor: pointer;
        box-shadow: 0 34px 38px rgba(0, 0, 0, 0.1);
    }

    .button span {
        margin-top: 10px;
    }

    .button:hover {
        background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
        background-size: 400% 400%;
        animation: gradient 15s ease infinite;
    }

    .content {
        display: none;
        padding: 6px 12px;
        border: 1px solid #ccc;
        border-radius: 4px;
        margin-top: 10px;
    }

    @keyframes gradient {
        0% {
            background-position: 0% 50%;
        }

        50% {
            background-position: 100% 50%;
        }

        100% {
            background-position: 0% 50%;
        }
    }
    </style>
</head>

<body>

    <div class="container">
        <h2>Grading System</h2>

        <a href="student/login.php" class="button">
            <span><i class="fas fa-user"></i></span>
            Go To Student
        </a>


        <a href="faculty/login.php" class="button">
            <span><i class="fas fa-chalkboard-teacher"></i></span>
            Go To Faculty
        </a>


        <a href="admin/adminlogin.php" class="button">
            <span><i class="fas fa-cogs"></i></span>
            Go To Admin
        </a>

    </div>

</body>

</html>