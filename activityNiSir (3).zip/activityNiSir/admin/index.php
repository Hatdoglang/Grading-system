<?php
session_start();
include("databse/dbcon.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <title>Document</title>
</head>
<style>
@import url("https://fonts.googleapis.com/css2?family=Poppins:wgh@400;500;600;700&display=swap");

* {
    margin: 0;
    padding: 0;
    outline: none;
    border: none;
    text-decoration: none;
    box-sizing: border-box;
    font-family: "Poppins", sans-serif;
}

body {
    background: #dfe9f5;
}

nav {
    position: absolute;
    top: 0;
    bottom: 0;
    height: 100%;
    left: 0;
    background: #fff;
    width: 90px;
    overflow: hidden;
    transition: widt 0.2s linear;
    box-shadow: 0 20px 35px rgba(0, 0, 0, 0.1);
}

.logo {
    text-align: center;
    display: flex;
    transition: all 0.5s ease;
    margin: 10px 0 0 10px;
}

.logo img {
    width: 45px;
    height: 45px;
    border: 50%;
}

.logo span {
    font-weight: bold;
    padding: 15px;
    font-size: 18px;
}

a {
    position: relative;
    color: rgb(85, 83, 83);
    font-size: 14px;
    display: table;
    width: 300px;
    padding: 10px;
}

.fas {
    position: relative;
    width: 70px;
    height: 45px;
    top: 14px;
    font-size: 20px;
    text-align: center;
}

.nav-item {
    position: relative;
    top: 12px;
    margin-left: 10px;
}

a:hover {
    background: #eee;
}

nav:hover {
    width: 280px;
    transition: all 0.5s ease;
}

.logout {
    position: absolute;
    bottom: 0;
}
</style>

<body>
    <nav>
        <ul>
            <li>
                <a href="profile.php" class="logo">
                    <img src="uploads/logo.jpeg" alt="Grading System Logo">
                    <span class="nav-item">Grading System</span>
                </a>
            </li>
            <li> <a href="dashboard.php">
                    <i class="fas fa-tachometer-alt dashboard-icon"></i>
                    <span class="nav-item">Dashboard</span>
                </a></li>
            <li> <a href="studenttable.php">
                    <i class="fas fa-user student-icon"></i>
                    <span class="nav-item">Student</span>
                </a></li>
            <li> <a href="facultyTable.php">
                    <i class="fas fa-user-tie faculty-icon"></i>
                    <span class="nav-item">Faculty</span>
                </a></li>

            <li> <a href="subjectTable.php">
                    <i class="fas fa-calendar-alt subject-icon"></i>
                    <span class="nav-item">Subject</span>
                </a></li>

            <li> <a href="courseTable.php">
                    <i class="fas fa-book-open course-icon"></i>
                    <span class="nav-item">Course</span>
                </a></li>

            <li> <a href="instituteTable.php">
                    <i class="fas fa-university institute-icon"></i>
                    <span class="nav-item">Institute</span>
                </a></li>


            <li> <a href="gradeTable.php">
                    <i class="fas fa-graduation-cap grade-icon"></i>
                    <span class="nav-item">Grade</span>
                </a></li>


            <li>
                <a href="schoolYearTable.php">
                    <i class="fas fa-calendar-alt grade-icon"></i>
                    <span class="nav-item">School Year</span>
                </a>
            </li>

            <li> <a href="adminlogin.php" class="logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <span class="nav-item">Logout</span>
                </a></li>

        </ul>
    </nav>
</body>

</html>