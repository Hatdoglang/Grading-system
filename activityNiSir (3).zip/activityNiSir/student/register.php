<?php
session_start();

include ("../admin/databse/dbcon.php");


if($_SERVER['REQUEST_METHOD'] == "POST")
{
    $fullname = isset($_POST['Namess']) ? $_POST['Namess'] : "";
    $username = isset($_POST['usernamess']) ? $_POST['usernamess'] : "";
    $password = isset($_POST['passwords']) ? $_POST['passwords'] : "";

    if(!empty($username) && !empty($password) && !is_numeric($username))
    {
        $query = "insert into users (Namess, usernamess,  passwords) values ('$fullname', '$username', '$password')";
        mysqli_query($con, $query);
        echo "<script type='text/javascript'> alert('Registration Successfuly')</script>";
    }
    else
    {
        echo "<script type='text/javascript'> alert('Registration Error')</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css



">
    <title>Login</title>
</head>
<style>
    body {
    background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
    background-size: 400% 400%;
    animation: gradient 15s ease infinite;
}

@keyframes gradient {
    0% {
        background-position: 0% 50%;
    }

    50% {
        background-position: 100% 50%;
    }

    100% {
        background-position: 0% 50%;
    }
}
.links{
    margin-top: 20px;
    font-size: 18px;
}
</style>
<body>

    <div class="wrapper">
        <form method="POST" class="form">
            <h1 class="title">Registration</h1>
            <div class="inp">
                <input type="text" name="Namess" class="input" placeholder="Full name">
                <i class="fa fa-users"></i>
            </div>
            <div class="inp">
                <input type="text" name="usernamess" class="input" placeholder="Username">
                <i class="fa fa-user"></i>
            </div>
            <div class="inp">
                <input type="password" name="passwords" class="input" placeholder="Password">
                <span class="password-toggle" onclick="togglePasswordVisibility()"><i class="fa fa-eye"></i></span>
            </div>
            <div class="inp">
                <input type="password" name="confirm_password" class="input" placeholder="Confirm Password">
                <i class="fa fa-lock"></i>
            </div>
            
            <button class="submit" type="submit" name="" value="Submit">Register</button>
            <p class="footer">ALREADY HAVE AN ACCOUNT? <a href="adminlogin.php" class="link">LOGIN HERE</a></p>
        </form>
        <div></div>
        <div></div>
        <div class="banner">
            <img style=" border-radius:50%;  height: 70px; width: 15%; position: absolute; margin-right:33px; margin-bottom: 22vh;"
                src="uploads/download.png" alt="">
            <h1 style=" font-family:Baskerville Old Face;  margin-top: 30px;" class="wel_text">Grading <br> System</h1>
        </div>
    </div>



    <script>
    function togglePasswordVisibility() {
        var passwordInput = document.querySelector("input[name='passwords']");
        var passwordToggle = document.querySelector(".password-toggle");

        if (passwordInput.type === "password") {
            passwordInput.type = "text";
            passwordToggle.innerHTML = '<i class="fa fa-eye-slash"></i>';
        } else {
            passwordInput.type = "password";
            passwordToggle.innerHTML = '<i class="fa fa-eye"></i>';
        }
    }
    </script>
</body>

</html>