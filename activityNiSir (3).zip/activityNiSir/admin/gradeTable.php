<?php
include("index.php");
include("databse/dbcon.php");
include("functions.php");

$faculty_query = "SELECT * FROM faculty";
$faculty_result = mysqli_query($con, $faculty_query);

// Query to get data from the "student" table
$student_query = "SELECT * FROM student";
$student_result = mysqli_query($con, $student_query);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <title>GRading System</title>
    <link rel="stylesheet" href="css/dashboard.css">
</head>

<body>
    <style>
    .list a {
        color: #fff;
        background: #5500cb;
        height: 45px;
        width: 160px;
        font-size: 18px;
        border-radius: 5px;
        cursor: pointer;
    }

    .recent-Articles {
        margin-left: 50vh;
        margin-top: 100px;
    }

    .data-table {
        width: 100%;
        max-width: 100%;
        border-collapse: collapse;
        white-space: nowrap;
        margin-top: 20px;
        background-color: #fff;
        border-radius: 20px;
        box-shadow: 3px 3px 10px rgba(0, 30, 87, 0.751);
    }

    .data-table td.no-wrap {
        white-space: nowrap;
        background-color: #ffffff;
        text-align: center;
    }

    /* Add this style for the "Full Name" column */
    .data-table td.no-wrap.full-name {
        text-align: left; /* Adjust as needed */
    }

    .search-container {
        text-align: center;
        margin: 20px 0;
    }

    #search-form {
        display: inline-block;
    }

    #search-input {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 5px;
        margin-right: 5px;
    }

    button[type="submit"] {
        background-color: #5500cb;
        color: white;
        border: none;
        padding: 8px 16px;
        border-radius: 5px;
        cursor: pointer;
    }
    .data-table td.pass {
            color: white;
            background: green;
            font-weight: bold;
        }

        .data-table td.fail {
            color: white;
            background: red;
            font-weight: bold;
        }

        .data-table td.n-a {
            color: gray;
            font-weight: bold;
        }
    </style>
    </nav>
    </div>
    <div class="main">
        

        <div style="margin-left:25vh;" class="report-container">
            <div class="report-header">
                <h1 class="recent-Articles">Grade of Students</h1>
            </div>

            <div class="search-container">
                <form id="search-form">
                    <input type="text" id="search-input" placeholder="Search for students">
                    <button type="submit">Search</button>
                </form>
            </div>
            <div class="report-body">
                <table class="data-table">


                    <thead>
                        <tr>
                            <th>Id Number</th>
                            <th>Full Name</th>
                            <th>Grade</th>
                            <th>Status</th>


                        </tr>
                    </thead>
                    <tbody>
                    <?php
                while ($row = mysqli_fetch_assoc($student_result)) {
                    echo '<tr>';
                    echo '<td class="no-wrap full-name">' . $row['idnumber'] . '</td>';
                    echo '<td class="no-wrap full-name">' . $row['lname'] . '&nbsp;&nbsp;&nbsp;' . $row['fname'] .  '</td>';
                    echo '<td class="no-wrap">' . $row['mark'] . '</td>';

                    // Use custom functions to determine Pass/Fail based on the grade
                    $status = getPassOrFail($row['mark']);
                    $statusClass = getPassOrFailClass($row['mark']);

                    echo '<td class="no-wrap ' . $statusClass . '">' . $status . '</td>';
                    echo '</tr>';
                }
                ?>
                    </tbody>
                </table>
            </div>
            <div id="not-found-message" style="display: none; margin-left: 400px; font-size: 20px; color: red;">No matching results found.</div>

        </div>
        </div>
        <script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchForm = document.getElementById("search-form");
        const searchInput = document.getElementById("search-input");
        const dataTable = document.querySelector(".data-table");
        const notFoundMessage = document.getElementById("not-found-message");

        searchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const searchValue = searchInput.value.toLowerCase();
            const rows = dataTable.querySelectorAll("tbody tr");
            let found = false;

            rows.forEach((row) => {
                const rowData = row.textContent.toLowerCase();
                if (rowData.includes(searchValue)) {
                    row.style.display = "";
                    found = true;
                } else {
                    row.style.display = "none";
                }
            });

            // Display or hide the "not found" message
            if (found) {
                notFoundMessage.style.display = "none";
            } else {
                notFoundMessage.style.display = "block";
            }
        });
    });
    </script>

</body>

</html>