<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if (isset($_POST['update'])) {
    // Get the updated data from the form
    $id = $_POST['id'];
    $code = $_POST['code'];
    $type = $_POST['type'];
    $unit = $_POST['unit'];
    $faculty = $_POST['facultyfk'];
        $studnet = $_POST['studentfk'];
    $desc = $_POST['description'];

    
   
    

    // Update the record in the database
    $updateSql = "UPDATE subjects SET code=?, type=?, unit=?, facultyfk=?, studentfk=?, description=? WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param("ssssssi", $code, $type, $unit, $faculty, $studnet, $desc,  $id);

    if ($stmt->execute()) {
        $_SESSION['success'] = "<h3 style='margin-left: 200px;'>Record Successfully Deleted</h3>";
        
    } else {
        $_SESSION['error'] = "Error updating record: " . $stmt->error;
    }

    // Redirect to the dashboard page
    header("location: subjectTable.php");
}
?>