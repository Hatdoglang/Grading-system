document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector('form');
    const firstForm = document.querySelector('.form.first');
    const secondForm = document.querySelector('.form.second');
    const nextBtn = document.querySelector('.nextBtn');
    const backBtn = document.querySelector('.backBtn');

    nextBtn.addEventListener('click', function () {
        // Add a class to the form to show the second section
        form.classList.add('secActive');
    });

    backBtn.addEventListener('click', function () {
        // Remove the class to go back to the first section
        form.classList.remove('secActive');
    });
});