<?php
session_start();
include("../admin/databse/dbcon.php");
include 'functions.php';

// Check if the user is logged in
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}

// Check if the Subject ID is provided in the URL
if (!isset($_GET['Subject_id'])) {
    echo "Subject ID not provided.";
    exit();
}

$user_id = $_SESSION['user_id'];
$subject_id = $_GET['Subject_id'];

// Query to get subject details
$subject_query = "SELECT * FROM subjects WHERE id = '$subject_id' AND facultyfk = '$user_id'";
$subject_result = mysqli_query($con, $subject_query);

// Check if the subject exists and belongs to the faculty
if (!$subject_result || mysqli_num_rows($subject_result) == 0) {
    echo "Subject not found or does not belong to the faculty.";
    exit();
}

$subject_data = mysqli_fetch_assoc($subject_result);

// Query to get the list of students for the specific subject
$students_query = "SELECT * FROM student WHERE subjectfk = '$subject_id'";
$students_result = mysqli_query($con, $students_query);


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/dashboard.css">

    <title>View Small</title>
</head>
<style>
body {
    background-color: #f4f4f4;
    margin: 0;
}

.dashboard {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    margin-right: 90px;
    color: #333;
}

.info-container {
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.label {
    font-weight: bold;
}




header {
    width: 100%;
    position: relative;
    height: 88px;
    background-color: white;
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    align-items: center;
    box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
}

.logo {
    font-size: 11px;
    font-weight: 600;
    color: #576cbc;
    margin-left: 20px;
    display: flex;
    align-items: center;
}

.logo h1 {
    color: #576cbc;
}

.hamburger {
    display: flex;
}


.nav-bar ul {
    display: flex;
    list-style: none;
    margin: 5px;
    padding: 5px;

}

.nav-bar ul li {
    display: flex;
    margin-right: 95px;

}

.nav-bar ul a {
    text-decoration: none;
    display: flex;
    position: absolute;
    margin-top: -10px;
    color: #576cbc;
    font-size: 18px;
    margin-left: 650px;
    transition: .2s;
}

.list a {
    color: #fff;
    background: #5500cb;
    height: 45px;
    width: 160px;
    font-size: 18px;
    border-radius: 5px;
    cursor: pointer;
}

.recent-Articles {
    margin-left: 50vh;
    margin-top: 100px;
}

.data-table {
    width: 100%;
    max-width: 100%;
    border-collapse: collapse;
    white-space: nowrap;
    margin-top: 20px;
    background-color: #fff;
    border-radius: 20px;
    box-shadow: 3px 3px 10px rgba(0, 30, 87, 0.751);
}

.data-table td.no-wrap {
    white-space: nowrap;
    background-color: #ffffff;
    text-align: center;
}

.search-container {

    margin-left: 760px;
}

#search-form {
    display: inline-block;
}

#search-input {
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-right: 5px;
}

button[type="submit"] {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}

/* Add space between the mark value and "Mark" link */
/* Display mark value on the left and "Mark" link on the right */
.mark-cell {
    display: flex;
    justify-content: space-between;
    align-items: center;
    white-space: nowrap;

}

.mark-cell span {
    font-size: 20px;
    font-weight: 600;
    color: white;
    background-color: #5500cb;
    padding: 2px 10px;
    border-radius: 5px;
}

.edit-mark-button {
    text-decoration: none;
    margin-left: 10px;
    color: white;
    font-weight: 600;
    background-color: #5500cb;
    padding: 5px 15px;
    border-radius: 5px;
}

/* Back button styles */
.back-button {
    text-decoration: none;
    background-color: #5500cb;
    position: absolute;
    margin-right: 190px;
    margin-top: 10px;
    color: white;
    padding: 8px 16px;
    border-radius: 5px;
    margin-bottom: 10px;
    display: inline-block;
    cursor: pointer;
}

.no-students-message {
    text-align: center;
    font-size: 39px;
    color: #555;
    font-weight: 600;
    margin-top: 20px;
}

.pass-fail-cell {
    text-align: center;
}

.pass {
    background: green;
    color: white;
    padding: 8px;
    border-radius: 3px;
}

.fail {
    background: red;
    color: white;
    padding: 8px;
    border-radius: 3px;
}
</style>

<body>


    <div style="margin-left:25vh;" class="report-container">
        <div class="report-header">
            <h1>Students for Subject: <?= $subject_data['code'] ?></h1>

        </div>
        <a href="javascript:history.back()" class="back-button">Back</a>

        <div class="search-container">

            <form id="search-form">

                <input type="text" id="search-input" placeholder="Search for students">
                <button type="submit">Search</button>

            </form>

        </div>

        <div class="report-body">
            <?php if (mysqli_num_rows($students_result) > 0) { ?>
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Id Number</th>
                        <th>Last Name</th>
                        <th>First Name</th>
                        <th>Course</th>
                        <th>Year Lvl</th>
                        <th>Semester</th>
                        <th>Student Mark</th>
                        <th>Time</th>
                        <th>Pass/Fail</th> <!-- New column -->

                    </tr>
                </thead>
                <tbody>
                <?php
while ($row = mysqli_fetch_assoc($students_result)) {
?>
    <tr>
        <td class="no-wrap"><?= $row['idnumber'] ?></td>
        <td class="no-wrap"><?= $row['lname'] ?></td>
        <td class="no-wrap"><?= $row['fname'] ?></td>
        <td class="no-wrap"><?= $row['course'] ?></td>
        <td class="no-wrap"><?= $row['yearLvl'] ?></td>
        <td class="no-wrap"><?= $row['semester'] ?></td>
        <td class="no-wrap mark-cell" data-student-id="<?= $row['id'] ?>">
            <span><?= $row['mark'] ?></span>
            <a href="#" class="edit-mark-button">Mark</a>
        </td>
        <td class="no-wrap"><?= $row['time'] ?></td>
        <td class="no-wrap pass-fail-cell <?= getPassOrFailClass($row['mark']) ?>">
            <span class="<?= getPassOrFailClass($row['mark']) ?>">
                <?= getPassOrFail($row['mark']) ?>
            </span>
        </td>
    </tr>
<?php
}
?>

                </tbody>
            </table>
            <?php } else { ?>
            <p class="no-students-message">No students enrolled</p>
            <?php } ?>
        </div>
        <div id="not-found-message" style="display: none; margin-left: 400px; font-size: 20px; color: red;">No
            matching results found.</div>


    </div>

    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchForm = document.getElementById("search-form");
        const searchInput = document.getElementById("search-input");
        const dataTable = document.querySelector(".data-table");
        const notFoundMessage = document.getElementById("not-found-message");

        searchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const searchValue = searchInput.value.toLowerCase();
            const rows = dataTable.querySelectorAll("tbody tr");
            let found = false;

            rows.forEach((row) => {
                const rowData = row.textContent.toLowerCase();
                if (rowData.includes(searchValue)) {
                    row.style.display = "";
                    found = true;
                } else {
                    row.style.display = "none";
                }
            });

            // Display or hide the "not found" message
            if (found) {
                notFoundMessage.style.display = "none";
            } else {
                notFoundMessage.style.display = "block";
            }
        });
    });
    </script>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        // Your existing JavaScript code

        // Additional JavaScript for handling the back button click
        const backButton = document.querySelector(".back-button");
        if (backButton) {
            backButton.addEventListener("click", function() {
                window.location.href = "Grade.php";
            });
        }
    });
    </script>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const editMarkButtons = document.querySelectorAll(".edit-mark-button");

        editMarkButtons.forEach(button => {
            button.addEventListener("click", function(e) {
                e.preventDefault();
                const markCell = button.closest(".mark-cell");
                const studentId = markCell.dataset.studentId;
                const currentMark = markCell.querySelector("span").textContent;
                const newMark = prompt("Enter new mark:", currentMark);

                if (newMark !== null) {
                    // Update the mark on the server
                    updateMark(studentId, newMark);
                }
            });
        });

        function updateMark(studentId, newMark) {

            fetch(`updateMark.php?student_id=${studentId}&new_mark=${newMark}`, {
                    method: 'GET',
                })
                .then(response => {
                    if (response.ok) {
                        alert("Mark updated successfully!");
                        // Update the mark on the page
                        const markCell = document.querySelector(
                            `.mark-cell[data-student-id="${studentId}"]`);
                        markCell.querySelector("span").textContent = newMark;
                    } else {
                        alert("Failed to update mark.");
                    }
                })
                .catch(error => {
                    console.error('Error updating mark:', error);
                    alert("An error occurred while updating the mark.");
                });
        }
    });
    </script>

</body>

</html>