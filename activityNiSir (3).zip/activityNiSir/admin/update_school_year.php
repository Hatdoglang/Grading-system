<?php
session_start(); // Start the session

include("databse/dbcon.php");

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the data from the POST request
    $id = $_POST['id'];
    $schoolYear = $_POST['school_year']; // Adjusted for the column name
    $semester = $_POST['Semester']; // Adjusted for the column name
    $status = $_POST['status']; // Adjusted for the column name

    // Update the record in the database
    $updateSql = "UPDATE schoolyear SET school_year=?, Semester=?, status=? WHERE id=?";

    $stmt = $con->prepare($updateSql);
    $stmt->bind_param("sssi", $schoolYear, $semester, $status, $id);

    if ($stmt->execute()) {
        echo "Record Successfully Updated";
    } else {
        echo "Error updating record: " . $stmt->error;
    }
}
?>
