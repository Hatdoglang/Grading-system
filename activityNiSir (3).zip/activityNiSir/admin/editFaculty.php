<?php

session_start(); 
include ("databse/dbcon.php");

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    $sql = "SELECT * FROM faculty WHERE id = '$id'";
    $result = $con->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            echo "Record not found.";
            exit();
        }
    } else {
        echo "Database error: " . $con->error;
        exit();
    }
} else {
    echo "Invalid request.";
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Edit Form</title>
    <style>
    body {
        background-color: #dfe9f5;
    }

    .registration-container {
        background: transparent;
        margin-top: 3%;
        padding: 3%;
        display: flex;
        justify-content: center;
        align-items: center;


    }

    .details-section {
        background: #fff;
        padding: 20px;
        border-radius: 15px;
        box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: #495057;
    }

    .three-details-item {
        display: flex;
        justify-content: space-between;
        flex-wrap: wrap;
    }

    label {
        width: calc(33.33% - 20px);
        margin-bottom: 20px;
    }

    label p {
        font-weight: bold;
        margin-bottom: 5px;
    }

    input {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #aaa;
        box-sizing: border-box;
    }

    select {
        width: 100%;
        padding: 10px;
        border-radius: 5px;
        border: 1px solid #aaa;
        box-sizing: border-box;
    }

    .container button,
    .backBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 100%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container button,
    .bacckBtn {
        display: flex;
        align-items: center;
        justify-content: center;
        height: 45px;
        max-width: 200px;
        width: 100%;
        border: none;
        outline: none;
        color: #fff;
        border-radius: 5px;
        margin: 25px 0;
        background-color: #4070f4;
        transition: all 0.3s linear;
        cursor: pointer;
    }

    .container button,
    .container .backBtn {
        font-size: 16px;
        font-weight: 400;
    }

    .container button,
    .container .bacckBtn {
        font-size: 16px;
        font-weight: 400;
    }

    button:hover {
        background-color: #265df2;
    }





    .buttons {
        position: absolute;
        margin-top: 200px;
        width: 900px;
        display: flex;
        align-items: center;
    }

    .buttons button,
    .backBtn {
        margin-right: 14px;
    }

    form {
        margin: 0 90px;
    }

    form h4 {
        font-size: 20px;
        font-weight: 600;
    }

    .buttons button,
    .bacckBtn {
        margin-right: 14px;
    }
    </style>
</head>

<body>
    <section class="registration-container">

        <section class="details-section">
            <form action="updateFaculty.php" method="post" class="registration-form" id="registration-form">
                <!-- Student Details Section -->
                <h4>Faculty Details</h4>
                <section class="personal-details">
                    <div class="three-details-item">
                        <label>
                            <p>ID</p>
                            <input type="text" name="id" value="<?= $row['id']; ?>" readonly>
                        </label>

                        <label>
                            <p>First Name</p>
                            <input type="text" name="f_name" value="<?= $row['f_name']; ?>" placeholder="First Name"
                                required>
                        </label>
                        <label>
                            <p>Last Name</p>
                            <input type="text" name="l_name" value="<?= $row['l_name']; ?>" placeholder="Last Name"
                                required>
                        </label>

                        <label>
                            <p>Middle Name</p>
                            <input type="text" name="m_name" value="<?= $row['m_name']; ?>" placeholder="m_name"
                                required>
                        </label>

                        <label>
                            <p>Date of Birth</p>
                            <input type="text" name="DOB" value="<?= $row['DOB']; ?>" placeholder="Date of Birth"
                                required>
                        </label>
                        <label>
                            <p>Gender</p>
                            <input type="text" name="Gender" value="<?= $row['Gender']; ?>" placeholder="Gender"
                                required>
                        </label>
                    </div>

                    <div class="three-details-item">

                        <label>
                            <p>Institute</p>
                            <select name="institute" required>
                                <?php
                                        $sql = "SELECT InstituteName, InstituteName FROM institute";
                                        $result = $con->query($sql);
                                            // Assuming $result contains the data from your database query
                                            while ($rowOption = $result->fetch_assoc()) {
                                                echo '<option value="' . $rowOption['InstituteName'] . '" ' . (($row['institute'] == $rowOption['InstituteName']) ? 'selected' : '') . '>' . $rowOption['InstituteName'] . '</option>';
                                            }
                                    ?>
                            </select>
                        </label>

                        <label>
                            <p>Subject</p>
                            <select name="subjectfk" required>
                                <?php
                                    $sql = "SELECT code, code FROM subjects";
                                    $result = $con->query($sql);

                                    // Assuming $result contains the data from your database query
                                    while ($rowOption = $result->fetch_assoc()) {
                                        echo '<option value="' . $rowOption['code'] . '" ' . (($row['subjectfk'] == $rowOption['code']) ? 'selected' : '') . '>' . $rowOption['code'] . '</option>';
                                    }
                                    ?>
                            </select>
                        </label>


                        <label>
                            <p>Course</p>
                            <input type="text" name="Course" value="<?= $row['Course']; ?>" placeholder="Course"
                                required>
                        </label>
                        <label>
                            <p>Contact Number</p>
                            <input type="text" name="ContactNum" value="<?= $row['ContactNum']; ?>"
                                placeholder="ContactNum" required>
                        </label>
                    </div>
                    <div class="bacckBtn" onclick="cancelRegistration()">
                        <i class="uil uil-navigator"></i>

                        <span class="btntext">Cancel</span>
                    </div>
                    <button style="margin-left:30vh; margin-top:-70px;" class="bacckBtn" type="submit" name="update">
                        <span class="bacckBtn">update</span>
                        <i class="uil uil-navigator"></i>
                    </button>
                </section>


            </form>
        </section>
    </section>
</body>
<script>
function cancelRegistration() {
    console.log("Cancel Registration function called");
    window.location.href = 'facultyTable.php';
}
</script>

</html>