<?php
session_start();
include("../admin/databse/dbcon.php");

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM student WHERE id = '$user_id'";
$result = mysqli_query($con, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);

    // Assuming 'subjectfk', 'mark', and 'yearLvl' columns exist in the 'student' table
    $grades_query = "SELECT s.code AS id, g.mark, g.yearLvl 
                     FROM student g
                     JOIN subjects s ON g.subjectfk = s.id
                     WHERE g.id = '$user_id'";
    $grades_result = mysqli_query($con, $grades_query);
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<style>

body {
    background-color: #f4f4f4;
    margin: 0;
}

.dashboard {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

.info-container {
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.label {
    font-weight: bold;
}

header {
    width: 100%;
    position: relative;
    height: 88px;
    background-color: white;
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    align-items: center;
    box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
}

.logo {
    font-size: 11px;
    font-weight: 600;
    color: #576cbc;
    margin-left: 20px;
    display: flex;
    align-items: center;
}

.logo h1 {
    color: #576cbc;
}

.hamburger {
    display: flex;
}

.nav-bar ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
}

.nav-bar ul li {
    margin-right: 95px;
}

.nav-bar ul a {
    text-decoration: none;
    display: flex;
    position: absolute;
    margin-top: -10px;
    color: #576cbc;
    font-size: 18px;
    margin-left: 795px;
    transition: .2s;
}
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    th, td {
        border: 1px solid #ddd;
        padding: 8px;
        text-align: left;
    }

    th {
        background-color: #f2f2f2;
    }
</style>

<body>
    <!-- Your existing HTML content here -->
    <header>
        <div class="logo">
            <div class="hamburger">
                <h1>Welcome, <?php echo $user_data['fname'] . ' ' . $user_data['lname']; ?>!</h1>
            </div>

            <nav class="nav-bar">
                <ul>
                    <li><a href="dashboard.php" class="active">Home</a></li>
                    <li><a href="profile.php" class="active">Profile</a></li>
                    <li><a href="studentGrade.php" class="active">Grade</a></li>
                    <li><a href="login.php" class="active">Logout</a></li>

                </ul>
                </ul>
            </nav>

        </div>
    </header>
    <div class="dashboard">
        <?php if (isset($user_data)) : ?>
            <h1>Welcome, <?php echo $user_data['fname'] . ' ' . $user_data['lname']; ?>!</h1>
        <?php else : ?>
            <p>Welcome!</p>
        <?php endif; ?>

        <!-- Other dashboard content -->

        <div class="info-container">
            <h2>Your Grades</h2>
            <table>
                <thead>
                    <tr>
                        <th>Subject</th>
                        <th>Mark</th>
                        <th>School Year</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    if ($grades_result && mysqli_num_rows($grades_result) > 0) {
                        while ($grade_row = mysqli_fetch_assoc($grades_result)) {
                            echo '<tr>';
                            echo '<td>' . $grade_row['id'] . '</td>';
                            echo '<td>' . $grade_row['mark'] . '</td>';
                            echo '<td>' . $grade_row['yearLvl'] . '</td>';
                            echo '</tr>';
                        }
                    } else {
                        echo '<tr><td colspan="3">No grades available</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</body>


</html>


