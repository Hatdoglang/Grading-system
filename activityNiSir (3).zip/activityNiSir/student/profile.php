<?php
session_start();
include("../admin/databse/dbcon.php");

// Check if the user is logged in, if not redirect to the login page
if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}


// Fetch user data based on the user_id stored in the session
$user_id = $_SESSION['user_id'];
$query = "SELECT * FROM student WHERE id = '$user_id'";
$result = mysqli_query($con, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $user_data = mysqli_fetch_assoc($result);
} else {
    // Handle the case where user data is not found (optional)
    echo "Error: User data not found";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Your additional styles and scripts can be included here -->
</head>
<style>
   body {
    background-color: #f4f4f4;
    margin: 0;
}
.registration-container {
    background: transparent;
    margin-top: 3%;
    padding: 3%;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-top: 10px;
}

.details-section {

    background: transparent;
    border-radius: 15px;
    height: 970px;
    box-shadow: 0px 0px 15px 0px rgba(0, 0, 0, 0.1);
}

h2 {
    text-align: center;
    color: #495057;
}

.three-details-item {
    display: flex;
    justify-content: space-between;
    flex-wrap: wrap;
}

label {
    width: calc(33.33% - 20px);
    margin-bottom: 20px;
}

label p {
    font-weight: 650;
    margin-bottom: 5px;
}

input {
    width: 90%;
    margin-left: 10px;
    height: 40px;
    border-radius: 5px;
    border: none;
    border-bottom: 1px solid black;
    background: transparent;


}

select {
    width: 90%;
    margin-left: 10px;
    height: 40px;
    border-radius: 5px;
    padding: 0 15px;


}


.container button,
.backBtn {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 45px;
    max-width: 200px;
    width: 100%;
    border: none;
    outline: none;
    color: #fff;
    border-radius: 5px;
    margin: 25px 0;
    background-color: #4070f4;
    transition: all 0.3s linear;
    cursor: pointer;
}

.container button,
.bacckBtn {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 45px;
    max-width: 200px;
    width: 100%;
    border: none;
    outline: none;
    color: #fff;
    border-radius: 5px;
    margin: 25px 0;
    background-color: #4070f4;
    transition: all 0.3s linear;
    cursor: pointer;
}

.container button,
.container .backBtn {
    font-size: 16px;
    font-weight: 400;
}

.container button,
.container .bacckBtn {
    font-size: 16px;
    font-weight: 400;
}

button:hover {
    background-color: #265df2;
}





.buttons {
    position: absolute;
    margin-top: 200px;
    width: 900px;
    display: flex;
    align-items: center;
}

.buttons button,
.backBtn {
    margin-right: 14px;
}

form {
    margin: 0 90px;
}

form h4 {
    font-size: 20px;
    font-weight: 600;
}

.buttons button,
.bacckBtn {
    margin-right: 14px;
}





.dashboard {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: #333;
}

.info-container {
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.label {
    font-weight: bold;
}

header {
    width: 100%;
    position: relative;
    height: 88px;
    background-color: white;
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    align-items: center;
    box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
}

.logo {
    font-size: 11px;
    font-weight: 600;
    color: #576cbc;
    margin-left: 20px;
    display: flex;
    align-items: center;
}

.logo h1 {
    color: #576cbc;
}

.hamburger {
    display: flex;
}

.nav-bar ul {
    display: flex;
    list-style: none;
    margin: 0;
    padding: 0;
}

.nav-bar ul li {
    margin-right: 95px;
}

.nav-bar ul a {
    text-decoration: none;
    display: flex;
    position: absolute;
    margin-top: -10px;
    color: #576cbc;
    font-size: 18px;
    margin-left: 795px;
    transition: .2s;
}
</style>
</style>

<body>
    <header>
        <div class="logo">
            <div class="hamburger">
            <h1>Welcome, <?php echo $user_data['fname'] . ' ' . $user_data['lname']; ?>!</h1>
            </div>

            <nav class="nav-bar">
                <ul>
                <li><a href="dashboard.php" class="active">Home</a></li>
                    <li><a href="profile.php" class="active">Profile</a></li>
                    <li><a href="studentGrade.php" class="active">Grade</a></li>
                    <li><a href="login.php" class="active">Logout</a></li>

                </ul>
            </nav>

        </div>
    </header>

    <section class="registration-container">
        <section class="details-section">
            <form action="updatestudent.php" method="post" class="registration-form" id="registration-form">
                <!-- Student Details Section -->

                <h4>Student Details</h4>
                <section class="personal-details">
                    <div class="three-details-item">
                        
                        <label>
                            <p>Student ID</p>
                            <input type="text" name="idnumber" value="<?php echo $user_data['idnumber']; ?>"
                                placeholder="Student ID" readonly>
                        </label>
                        <label>
                            <p>First Name</p>
                            <input type="text" name="fname" value="<?php echo $user_data['fname']; ?>"
                                placeholder="First Name" readonly>
                        </label>
                        <label>
                            <p>Last Name</p>
                            <input type="text" name="lname" value="<?php echo $user_data['lname']; ?>"
                                placeholder="Last Name" readonly>
                        </label>
                        <label>
                            <p>Middle Name</p>
                            <input type="text" name="mname" value="<?php echo $user_data['mname']; ?>"
                                placeholder="Middle" readonly>
                        </label>
                        
                        <label>
                            <p>Gender</p>
                            <input type="text" name="gender" value="<?php echo $user_data['gender']; ?>"
                                placeholder="Middle" readonly>
                        </label>
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

                    </div>

                    <div class="three-details-item">
                        <label>
                            <p>Institute</p>
                            <input type="text" name="institute" value="<?php echo $user_data['institute']; ?>"
                                placeholder="Middle" readonly>
                        </label>


                        <label>
                            <p>Course</p>
                            <input type="text" name="course" value="<?php echo $user_data['course']; ?>"
                                placeholder="Middle" readonly>
                        </label>
                        <label>
                            <p>Date of Birth</p>
                            <input type="date" name="dob" value="<?php echo $user_data['dob']; ?>"
                                placeholder="Date of Birth" readonly>
                        </label>
                    </div>
                    <h4>Home Address</h4>
                    <div class="three-details-item">
                        <label>
                            <p>Province</p>
                            <input type="text" name="province" value="<?php echo $user_data['province']; ?>"
                                placeholder="Province" readonly>
                        </label>

                        <label>
                            <p>Municipality</p>
                            <input type="text" name="municipality" value="<?php echo $user_data['municipality']; ?>"
                                placeholder="Municipality" readonly>
                        </label>
                        <label>
                            <p>Barangay</p>
                            <input type="text" name="barangay" value="<?php echo $user_data['barangay']; ?>"
                                placeholder="Barangay" readonly>
                        </label>
                        <label>
                            <p>Purok</p>
                            <input type="text" name="purok" value="<?php echo $user_data['purok']; ?>" placeholder="Purok"
                                readonly>
                        </label>

                        <label>
                            <p>Zip Code</p>
                            <input type="text" name="zipcode" value="<?php echo $user_data['zipcode']; ?>"
                                placeholder="Zip Code" readonly>
                        </label>
                        <label>
                            <p>Contact No.</p>
                            <input type="text" name="student_contact" value="<?php echo $user_data['student_contact']; ?>"
                                placeholder="Contact" readonly>
                        </label>
                    </div>

                    <h4>In-case of Emergency</h4>
                    <div class="three-details-item">
                        <label>
                            <p>Guardian</p>
                            <input type="text" name="guardian" value="<?php echo $user_data['guardian']; ?>"
                                placeholder="Guardian" readonly>
                        </label>
                        <label>
                            <p>Contact Number</p>
                            <input type="text" name="contnumber" value="<?php echo $user_data['contnumber']; ?>"
                                placeholder="Contact Number" readonly>
                        </label>
                        <label>
                            <p>Address</p>
                            <input type="text" name="address" value="<?php echo $user_data['address']; ?>"
                                placeholder="Address" readonly>
                        </label>
                    </div>

                </section>
            </form>
        </section>
    </section>

</body>

</html>