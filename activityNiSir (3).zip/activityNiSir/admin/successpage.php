<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success Page</title>
</head>
<body>
    <h1>Operation Successful!</h1>
    <p>Your operation was successful. You can add additional information or links on this page.</p>

    <!-- You may provide a link to navigate back to the main page or any other relevant pages -->
    <a href="index.php">Go back to the main page</a>
</body>
</html>
