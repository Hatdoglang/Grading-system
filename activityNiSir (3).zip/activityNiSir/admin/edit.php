<?php

session_start(); // Start the session
include ("databse/dbcon.php");

if (isset($_GET['edit'])) {
    $id = $_GET['edit'];

    // Check if the ID exists in the database
    $sql = "SELECT * FROM student WHERE id = '$id'";
    $result = $con->query($sql);

    if ($result) {
        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
        } else {
            // Handle the case where the ID does not exist in the database
            echo "Record not found.";
            exit();
        }
    } else {
        // Handle the case where the database query has an error
        echo "Database error: " . $con->error;
        exit();
    }
} else {
    // Handle the case where 'edit' parameter is not set in the URL
    echo "Invalid request.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Edit Form</title>
    <link rel="stylesheet" href="css/studen.css">
</head>

<body>
    <section class="registration-container">
        <h2>Edit Student Details</h2>
        <section class="details-section">
            <form action="update.php" method="post" class="registration-form" id="registration-form">
                <!-- Student Details Section -->
                <h4>Student Details</h4>
                <section class="personal-details">
                    <div class="three-details-item">
                        <label>
                            <p>ID</p>
                            <input type="text" name="id" value="<?= $row['id']; ?>" readonly>
                        </label>
                        <label>
                            <p>First Name</p>
                            <input type="text" name="fname" value="<?= $row['fname']; ?>" placeholder="First Name"
                                required>
                        </label>
                        <label>
                            <p>Last Name</p>
                            <input type="text" name="lname" value="<?= $row['lname']; ?>" placeholder="Last Name"
                                required>
                        </label>
                        <label>
                            <p>Middle Name</p>
                            <input type="text" name="mname" value="<?= $row['mname']; ?>" placeholder="Middle" required>
                        </label>
                        <label>
                            <p>Gender</p>
                            <input type="text" name="gender" value="<?= $row['gender']; ?>" placeholder="Gender"
                                required>
                        </label>
                    </div>

                    <div class="three-details-item">
                        <label>
                            <p>Institute</p>
                            <input type="text" name="institute" value="<?= $row['institute']; ?>"
                                placeholder="Institute" required>
                        </label>
                        <label>
                            <p>Course</p>
                            <input type="text" name="course" value="<?= $row['course']; ?>" placeholder="Course"
                                required>
                        </label>
                        <label>
                            <p>Date of Birth</p>
                            <input type="text" name="dob" value="<?= $row['dob']; ?>" placeholder="Date of Birth"
                                required>
                        </label>
                        <label>
                            <p>Province</p>
                            <input type="text" name="province" value="<?= $row['province']; ?>" placeholder="Province"
                                required>
                        </label>
                    </div>
                    <div class="three-details-item">
                        <label>
                            <p>Municipality</p>
                            <input type="text" name="municipality" value="<?= $row['municipality']; ?>"
                                placeholder="Municipality" required>
                        </label>
                        <label>
                            <p>Barangay</p>
                            <input type="text" name="barangay" value="<?= $row['barangay']; ?>" placeholder="Barangay"
                                required>
                        </label>
                        <label>
                            <p>Purok</p>
                            <input type="text" name="purok" value="<?= $row['purok']; ?>" placeholder="Purok" required>
                        </label>
                        <label>
                            <p>Zip Code</p>
                            <input type="text" name="zipcode" value="<?= $row['zipcode']; ?>" placeholder="Zip Code"
                                required>
                        </label>
                    </div>
                </section>

                <label>
                    <p>Guardian</p>
                    <input type="text" name="guardian" value="<?= $row['guardian']; ?>" placeholder="Guardian" required>
                </label>
                <label>
                    <p>Contact Number</p>
                    <input type="text" name="contnumber" value="<?= $row['contnumber']; ?>" placeholder="Contact Number"
                        required>
                </label>
                <label>
                    <p>Address</p>
                    <input type="text" name="address" value="<?= $row['address']; ?>" placeholder="Address" required>
                </label>

                <button class="submit-btn" type="submit" name="update">UPDATE</button>
                <a style="text-align:center; text-decoration:none;" href="dashboard.php" class="submit-btn">BACK</a>
            </form>
        </section>
    </section>

    </section>
</body>

</html>