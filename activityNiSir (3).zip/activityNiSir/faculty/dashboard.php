<?php
session_start();
include("../admin/databse/dbcon.php");

if (!isset($_SESSION['user_id']) || empty($_SESSION['user_id'])) {
    header("location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Query to get data about the logged-in user from the faculty table
$faculty_query = "SELECT * FROM faculty WHERE id = '$user_id'";
$faculty_result = mysqli_query($con, $faculty_query);

if (!$faculty_result || mysqli_num_rows($faculty_result) == 0) {
    echo "Error: User data not found";
    exit();
}

$user_data = mysqli_fetch_assoc($faculty_result);

// Query to get the total number of students for the logged-in faculty
$student_count_query = "SELECT COUNT(*) as total_students
                       FROM student
                       WHERE facultyfk = '$user_id'";
$student_count_query_run = mysqli_query($con, $student_count_query);
////////////////////////
// Query to get the subjectfk data
$subjectfk_query = "SELECT subjectfk FROM faculty WHERE id = '$user_id'";
$subjectfk_result = mysqli_query($con, $subjectfk_query);

if (!$subjectfk_result) {
    echo "Error: Unable to fetch subjectfk data.";
    exit();
}

$subjectfk_data = mysqli_fetch_assoc($subjectfk_result);
$subjectfk_value = $subjectfk_data['subjectfk'];

// diplay in the table all of the student registered
$student_query = "SELECT * FROM student WHERE facultyfk = '$user_id'";
$student_result = mysqli_query($con, $student_query);

if (!$student_result) {
    // Handle the error, e.g., display an error message or redirect
    echo "Error: Unable to fetch student data.";
    exit();
}
// Query to get the total number of female students for the logged-in faculty
$female_students_query = "SELECT COUNT(*) as total_female_students
                          FROM student
                          WHERE facultyfk = '$user_id' AND gender = 'Female'";
$female_students_result = mysqli_query($con, $female_students_query);

if (!$female_students_result) {
    // Handle the error, e.g., display an error message or redirect
    echo "Error: Unable to fetch female students data.";
    exit();
}
// Query to get the total number of male students for the logged-in faculty
$male_students_query = "SELECT COUNT(*) as total_male_students
                        FROM student
                        WHERE facultyfk = '$user_id' AND gender = 'Male'";
$male_students_result = mysqli_query($con, $male_students_query);

if (!$male_students_result) {
    // Handle the error, e.g., display an error message or redirect
    echo "Error: Unable to fetch male students data.";
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"
        integrity="sha512-B4V40MP5ZTzWn1F0x6PWo+KBLkd4tRvx5iEz73hR5BHl3/9fizIkvI4sYFExl8clp4O6v0P/p2/dgBb6LHiXM2Q=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <title>Dashboard</title>
</head>
<style>
body {
    background-color: #f4f4f4;
    margin: 0;
}

.dashboard {
    max-width: 800px;
    margin: 20px auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    margin-right: 90px;
    color: #333;
}

.info-container {
    margin-top: 20px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    padding: 10px;
    background-color: #f0f0f0;
    border-radius: 5px;
}

.label {
    font-weight: bold;
}




header {
    width: 100%;
    position: relative;
    height: 88px;
    background-color: white;
    display: flex;
    justify-content: space-between;
    padding: 0 20px;
    align-items: center;
    box-shadow: 0 16px 8px -9px rgba(191, 191, 191);
}

.logo {
    font-size: 11px;
    font-weight: 600;
    color: #576cbc;
    margin-left: 20px;
    display: flex;
    align-items: center;
}

.logo h1 {
    color: #576cbc;
}

.hamburger {
    display: flex;
}


.nav-bar ul {
    display: flex;
    list-style: none;
    margin: 5px;
    padding: 5px;

}

.nav-bar ul li {
    display: flex;
    margin-right: 95px;

}

.nav-bar ul a {
    text-decoration: none;
    display: flex;
    position: absolute;
    margin-top: -10px;
    color: #576cbc;
    font-size: 18px;
    margin-left: 650px;
    transition: .2s;
}

.list a {
    color: #fff;
    background: #5500cb;
    height: 45px;
    width: 160px;
    font-size: 18px;
    border-radius: 5px;
    cursor: pointer;
}

.recent-Articles {
    margin-left: 50vh;
    margin-top: 100px;
}

.data-table {
    width: 100%;
    max-width: 100%;
    border-collapse: collapse;
    white-space: nowrap;
    margin-top: 20px;
    background-color: #fff;
    border-radius: 20px;
    box-shadow: 3px 3px 10px rgba(0, 30, 87, 0.751);
}

.data-table td.no-wrap {
    white-space: nowrap;
    background-color: #ffffff;
    text-align: center;
}

.search-container {

    margin-left: 760px;
}

#search-form {
    display: inline-block;
}

#search-input {
    padding: 8px;
    border: 1px solid #ccc;
    border-radius: 5px;
    margin-right: 5px;
}

button[type="submit"] {
    background-color: #5500cb;
    color: white;
    border: none;
    padding: 8px 16px;
    border-radius: 5px;
    cursor: pointer;
}
</style>

<body>
    <header>
        <div class="logo">
            <div class="hamburger">
                <h1>Welcome, <?php echo $user_data['f_name'] ?>!</h1>
            </div>

            <nav class="nav-bar">
                <ul>
                    <li><a href="dashboard.php" class="active">Home</a></li>
                    <li><a href="student.php" class="active">Students</a></li>
                    <li><a href="Grade.php" class="active">Grade</a></li>
                    <li><a href="Report.php" class="active">Report</a></li>
                    <li><a href="login.php" class="active">Logout</a></li>

                </ul>
                </ul>
            </nav>

        </div>
    </header>

    <div class="main">
        <div class="box-container">
            <!-- Display Total Subjects -->

            <div class="box box1">
    <div class="text">
    </div>

    <?php
    $user_id = mysqli_real_escape_string($con, $user_id);

    $subject_query = "SELECT subjectfk FROM faculty WHERE id = '$user_id'";
    $subject_result = mysqli_query($con, $subject_query);

    if (!$subject_result) {
        echo "Error: " . mysqli_error($con);
        exit();
    }

    $subject_data = mysqli_fetch_assoc($subject_result);

    if ($subject_data !== null) {
        $subjectfk_value = $subject_data['subjectfk'];

        $subjects_query = "SELECT * FROM subjects WHERE code = '$subjectfk_value'";
        $subjects_result = mysqli_query($con, $subjects_query);

        if ($subjects_result) {
            echo '<h2 class="topic-heading" style="color:white; font-size:18px;"></h2>';
            echo '<ul>';
            while ($subjects_data = mysqli_fetch_assoc($subjects_result)) {
                echo '<li style="color:white; font-size:18px; list-style-type: none;">';
                echo 'Faculty Id: ' . $subjects_data['facultyfk'] . '<br> Code: ' . $subjects_data['code'];
                echo '</li>';
            }
            echo '</ul>';
        } else {
            echo "Error fetching rows from subjects: " . mysqli_error($con);
        }
    } else {
        echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:18px;">No data</h2>';
    }
    ?>
</div>











            <div class="box box2">
                <div class="text">
                    <h2 class="topic">Total Students</h2>
                </div>

                <?php
                if ($student_count_query_run && mysqli_num_rows($student_count_query_run) > 0) {
                    $total_students_data = mysqli_fetch_assoc($student_count_query_run);
                    $total_students = $total_students_data['total_students'];

                    echo '<h2 class="topic-heading" style="color:white; font-size:28px;">  "' . $total_students . '"</h2>';
                } else {
                    echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:8px;">No data</h2>';
                }
                ?>
            </div>


            <!-- Display Total Female Students -->
            <div class="box box3">
                <div class="text">
                    <h2 class="topic">Total Female Students</h2>
                </div>

                <?php
                        if ($female_students_result && mysqli_num_rows($female_students_result) > 0) {
                            $total_female_students_data = mysqli_fetch_assoc($female_students_result);
                            $total_female_students = $total_female_students_data['total_female_students'];

                            echo '<h2 class="topic-heading" style="color:white;">"' . $total_female_students . '"</h2>';
                        } else {
                            echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:18px;">No female students data</h2>';
                        }
                 ?>
            </div>

            <!-- Display Total Male Students -->
            <div class="box box4">
                <div class="text">
                    <h2 class="topic">Total Male <br> Students</h2>
                </div>

                <?php
                if ($male_students_result && mysqli_num_rows($male_students_result) > 0) {
                    $total_male_students_data = mysqli_fetch_assoc($male_students_result);
                    $total_male_students = $total_male_students_data['total_male_students'];

                    echo '<h2 class="topic-heading" style="color:white;">"' . $total_male_students . '"</h2>';
                } else {
                    echo '<h2 class="topic-heading" style="color:white; margin-left:30px; font-size:18px;">No male students data</h2>';
                }
                ?>
            </div>

        </div>

        <div style="margin-left:25vh;" class="report-container">
            <div class="report-header">
                <h1 style="position: relative; margin-top:-30px;" class="recent-Articles">Registered Students</h1>
            </div>

            <div class="search-container">
                <form id="search-form">
                    <input type="text" id="search-input" placeholder="Search for students">
                    <button type="submit">Search</button>
                </form>
            </div>
            <div class="report-body">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Id Number</th>
                            <th>Last Name</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Gender</th>
                            <th>Course</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
            while ($row = mysqli_fetch_assoc($student_result)) {
                echo '<tr>';
                echo '<td class="no-wrap">' . $row['idnumber'] . '</td>';
                echo '<td class="no-wrap">' . $row['lname'] . '</td>';
                echo '<td class="no-wrap">' . $row['fname'] . '</td>';
                echo '<td class="no-wrap">' . $row['mname'] . '</td>';
                echo '<td class="no-wrap">' . $row['gender'] . '</td>';
                echo '<td class="no-wrap">' . $row['course'] . '</td>';
                echo '</tr>';
            }
            ?>
                    </tbody>
                </table>
            </div>
            <div id="not-found-message" style="display: none; margin-left: 400px; font-size: 20px; color: red;">No
                matching results found.</div>


        </div>
    </div>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        const searchForm = document.getElementById("search-form");
        const searchInput = document.getElementById("search-input");
        const dataTable = document.querySelector(".data-table");
        const notFoundMessage = document.getElementById("not-found-message");

        searchForm.addEventListener("submit", function(e) {
            e.preventDefault();
            const searchValue = searchInput.value.toLowerCase();
            const rows = dataTable.querySelectorAll("tbody tr");
            let found = false;

            rows.forEach((row) => {
                const rowData = row.textContent.toLowerCase();
                if (rowData.includes(searchValue)) {
                    row.style.display = "";
                    found = true;
                } else {
                    row.style.display = "none";
                }
            });

            // Display or hide the "not found" message
            if (found) {
                notFoundMessage.style.display = "none";
            } else {
                notFoundMessage.style.display = "block";
            }
        });
    });
    </script>

</body>

</html>